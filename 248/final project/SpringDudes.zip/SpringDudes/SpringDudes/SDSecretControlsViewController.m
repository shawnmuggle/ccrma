//
//  SDSecretControlsViewController.m
//  SpringDudes
//
//  Created by Luke Iannini on 3/18/12.
//  Copyright (c) 2012 Rototyping. All rights reserved.
//

#import "SDSecretControlsViewController.h"

@interface SDSecretControlsViewController ()

- (IBAction)doneAction:(id)sender;
@end

@implementation SDSecretControlsViewController
@synthesize delegate;
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
	return YES;
}

- (IBAction)doneAction:(id)sender
{
    [self.delegate secretControlsViewControllerDidFinish:self];
}
@end
