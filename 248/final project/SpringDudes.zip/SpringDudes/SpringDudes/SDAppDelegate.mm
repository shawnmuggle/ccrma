//
//  SDAppDelegate.m
//  SpringDudes
//
//  Created by Michael Rotondo on 2/19/12.
//  Copyright (c) 2012 Rototyping. All rights reserved.
//

#import "SDAppDelegate.h"
#import "Pulsar.h"
#import "MFCoreDataStack.h"
#import "SDViewController.h"
#import "MagicFile.h"
#import "MFBonjourFinder.h"

@implementation SDAppDelegate
{
    MFCoreDataStack *model;
    MFObjectTranslator *objectTranslator;
    MFBonjourFinder *bonjourFinder;
}

@synthesize window = _window;

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    [Pulsar sharedPulsar];
    
    model = [MFCoreDataStack coreDataStackWithModelName:@"SpringDudes"];
    
#warning TODO(mrotondo): Uncomment this! It is only commented out for 248 preso's sake
//    objectTranslator = [MFObjectTranslator objectTranslatorForContext:model.managedObjectContext];
    
    SDViewController *viewController = (SDViewController *)self.window.rootViewController;
    viewController.managedObjectContext = model.managedObjectContext;
    
    [application setIdleTimerDisabled:YES];
    
    // Override point for customization after application launch.
    return YES;
}
							
- (void)applicationWillResignActive:(UIApplication *)application
{
    /*
     Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
     Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
     */

    SDViewController *viewController = (SDViewController *)self.window.rootViewController;
    NSError *error;
    BOOL success = [viewController.managedObjectContext save:&error];
    if (!success)
    {
        NSLog(@"Error while saving context: %@", error);
    }
}

- (void)applicationDidEnterBackground:(UIApplication *)application
{
    /*
     Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later. 
     If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
     */
}

- (void)applicationWillEnterForeground:(UIApplication *)application
{
    /*
     Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
     */
}

- (void)applicationDidBecomeActive:(UIApplication *)application
{
    /*
     Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
     */
}

- (void)applicationWillTerminate:(UIApplication *)application
{
    /*
     Called when the application is about to terminate.
     Save data if appropriate.
     See also applicationDidEnterBackground:.
     */
}

@end
