//
//  SDSecretGesture.h
//  SpringDudes
//
//  Created by Luke Iannini on 3/18/12.
//  Copyright (c) 2012 Rototyping. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef void(^SDSecretGestureBlock)(void);

@interface SDSecretGesture : NSObject

+ (SDSecretGesture *)secretGestureAddedToView:(UIView *)aView withEffect:(SDSecretGestureBlock)block;

@end
