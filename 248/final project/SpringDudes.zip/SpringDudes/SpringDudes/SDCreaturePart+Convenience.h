//
//  SDCreaturePart+Convenience.h
//  SpringDudes
//
//  Created by Michael Rotondo on 3/7/12.
//  Copyright (c) 2012 Rototyping. All rights reserved.
//

#import "SDCreaturePart.h"

@interface SDCreaturePart (Convenience)

@property (nonatomic) GLKVector3 primaryColor;
@property (nonatomic) GLKVector3 secondaryColor;
@property (nonatomic) GLKVector2 originalPosition;

@end
