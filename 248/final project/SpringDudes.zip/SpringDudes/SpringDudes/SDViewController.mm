//
//  SDViewController.m
//  SpringDudes
//
//  Created by Michael Rotondo on 2/19/12.
//  Copyright (c) 2012 Rototyping. All rights reserved.
//

#import "SDViewController.h"
#import "Box2D/Box2D.h"
#import <objc/runtime.h>
#import "SDWorld.h"
#import "SDWorldTerrain.h"
#import "SDCreature.h"
#import "MagicFile.h"
#import "SDSimpleEffect.h"
#import "SDTerrainEffect.h"
#import "SDCreaturePartEffect.h"
#import "SDWorldSound.h"
#import "SDEffectsManager.h"
#import "SDSecretGesture.h"
#import "SDSecretControlsViewController.h"
#import "SDGLKitHelper.h"

#include "glUtil.h"
#define GetGLError()									\
{														\
GLenum err = glGetError();							\
while (err != GL_NO_ERROR) {						\
NSLog(@"GLError %s set in File:%s Line:%d\n",	\
GetGLErrorString(err),					\
__FILE__,								\
__LINE__);								\
err = glGetError();								\
}													\
}

@interface SDViewController () <MFTransactionObserverDelegate, SDSecretControlsViewControllerDelegate>
@property (strong, nonatomic) EAGLContext *glContext;

- (GLKVector2)transformTouchLocationIntoWorld:(UITouch *)touch;
- (void)setupGL;
- (void)tearDownGL;

- (void)generateTextures;

@end

@implementation SDViewController
{
    float scaleFactor;
    SDWorld *world;
    MFTransactionObserver *magicFileTransactionObserver;
    NSMutableSet *creaturesBeingDrawn;
    SDWorldSound *worldSound;
    SDSecretGesture *secretGesture;
    
    NSDictionary *effects;

    float worldWidth;
    float xOffset;
    
    GLKTextureInfo *grassTexture;
    
    GLuint diffuseGrassTextureID;
    GLuint diffuseGrassTextureFBO;
    GLuint diffuseGrassTextureRB;
}
@synthesize managedObjectContext;
@synthesize glContext = _context;

- (GLKVector2)transformTouchLocationIntoWorld:(UITouch *)touch
{
    CGPoint loc = [touch locationInView:touch.view];
    GLKVector2 vertex = GLKVector2Make(loc.x * 2.0f / touch.view.bounds.size.width - 1.0f, 
                                       -1.0f * (loc.y * 2.0f / touch.view.bounds.size.height - 1.0f));
    GLKVector2 scaledVertex = GLKVector2MultiplyScalar(vertex, scaleFactor);
    GLKVector2 offsetVertex = GLKVector2Add(scaledVertex, GLKVector2Make(xOffset, scaleFactor / 2));
    return offsetVertex;
}

static char kSDTouchCreatureKey;

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    for (UITouch *touch in touches)
    {
        SDCreature *creature = [SDCreature creatureInManagedObjectContext:self.managedObjectContext];
        [creature mf_broadcastCreationBy:self];
        objc_setAssociatedObject(touch, &kSDTouchCreatureKey, creature, OBJC_ASSOCIATION_ASSIGN);
    }
}

- (void)touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event
{
    for (UITouch *touch in touches)
    {
        SDCreature *creature = objc_getAssociatedObject(touch, &kSDTouchCreatureKey);
        GLKVector2 vertex = [self transformTouchLocationIntoWorld:touch];
        [creature addPoint:vertex];
    }
}

- (void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event
{
    for (UITouch *touch in touches)
    {
        SDCreature *creature = objc_getAssociatedObject(touch, &kSDTouchCreatureKey);
        [creature mf_broadcastCompletionBy:self];
    }
    
//    GLKView *glkView = (GLKView *)self.view;
//    UIImage *shot = [glkView snapshot];
}

- (void)touchesCancelled:(NSSet *)touches withEvent:(UIEvent *)event
{
    [self touchesEnded:touches withEvent:event];
}

- (void)viewDidLoad
{
    [super viewDidLoad];

    self.glContext = [[EAGLContext alloc] initWithAPI:kEAGLRenderingAPIOpenGLES2];
    
    if (!self.glContext) {
        NSLog(@"Failed to create ES context");
    }
    
    GLKView *view = (GLKView *)self.view;
    view.context = self.glContext;
    view.drawableDepthFormat = GLKViewDrawableDepthFormat24;
    
    [self setupGL];
    
    self.preferredFramesPerSecond = 15;
    
    srand((unsigned int)time(NULL));
    
    scaleFactor = 10.0f;
    worldWidth = scaleFactor * 2.0f;

    float bigWorldWidth = 40.0f;  // We just know, ok!?
    
    // For my 248 presentation, we don't offset
    xOffset = 0.0f;//(bigWorldWidth / 2.0f) * ((arc4random() / (float)0x100000000) * 2 - 1);
    
    world = [SDWorld singletonWorldInManagedObjectContext:self.managedObjectContext];
    if (!world.initialized)
    {
        // This should only happen the first time this view loads
        [world initializeWithWidth:worldWidth andXOffset:xOffset];
    }
    
    worldSound = [SDWorldSound defaultWorldSound];
    
    creaturesBeingDrawn = [NSMutableSet setWithCapacity:11];
        
    magicFileTransactionObserver = [MFTransactionObserver transactionObserverWithDelegate:self];
    magicFileTransactionObserver.ignoreMessagesNotFromObject = self;
    
    __weak SDViewController *weakSelf = self;
    secretGesture = [SDSecretGesture secretGestureAddedToView:self.view withEffect:^{
        [weakSelf performSegueWithIdentifier:@"showSecretControls" sender:self];
    }];
}

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    if ([[segue identifier] isEqualToString:@"showSecretControls"])
    {
        SDSecretControlsViewController *secretViewController = [segue destinationViewController];
        secretViewController.delegate = self;
    }
}

- (void)secretControlsViewControllerDidFinish:(SDSecretControlsViewController *)aSecretControlsViewController
{
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    
    [self tearDownGL];
    
    if ([EAGLContext currentContext] == self.glContext) {
        [EAGLContext setCurrentContext:nil];
    }
	self.glContext = nil;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Release any cached data, images, etc. that aren't in use.
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone) {
        return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
    } else {
        return YES;
    }
}

- (void)setupGL
{
    [EAGLContext setCurrentContext:self.glContext];
//    glEnable(GL_DEPTH_TEST);
//    glEnable( GL_TEXTURE_2D );
    
    [SDEffectsManager initializeSharedEffectsManager];
    
    [self generateTextures];
}

#define MAP_SIZE 256

- (void)generateTextures
{
    GLuint framebuffer;
    glGenFramebuffers(1, &framebuffer);
    glBindFramebuffer(GL_FRAMEBUFFER, framebuffer);
    
    GLuint colorRenderbuffer;
    glGenRenderbuffers(1, &colorRenderbuffer);
    glBindRenderbuffer(GL_RENDERBUFFER, colorRenderbuffer);
    glRenderbufferStorage(GL_RENDERBUFFER, GL_RGBA8_OES, MAP_SIZE, MAP_SIZE);
    glFramebufferRenderbuffer(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL_RENDERBUFFER, colorRenderbuffer);
    
    // create the texture
    GLuint texture;
    glGenTextures(1, &texture);
    glBindTexture(GL_TEXTURE_2D, texture);
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA,  MAP_SIZE, MAP_SIZE, 0, GL_RGBA, GL_UNSIGNED_BYTE, NULL);
    glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL_TEXTURE_2D, texture, 0);
    
    GLuint depthRenderbuffer;
    glGenRenderbuffers(1, &depthRenderbuffer);
    glBindRenderbuffer(GL_RENDERBUFFER, depthRenderbuffer);
    glRenderbufferStorage(GL_RENDERBUFFER, GL_DEPTH_COMPONENT16, MAP_SIZE, MAP_SIZE);
    glFramebufferRenderbuffer(GL_FRAMEBUFFER, GL_DEPTH_ATTACHMENT, GL_RENDERBUFFER, depthRenderbuffer);
    
    GLenum status = glCheckFramebufferStatus(GL_FRAMEBUFFER) ;
    if(status != GL_FRAMEBUFFER_COMPLETE) {
        NSLog(@"failed to make complete framebuffer object %x", status);
    }
    
    glViewport(0, 0, MAP_SIZE, MAP_SIZE);
    
    glClearColor(0.0, 0.0, 0.0, 1.0);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    
    GLKMatrix4 zeroToOneOrtho = GLKMatrix4MakeOrtho(0, 1, 0, 1, -1, 1);
    [SDEffectsManager setProjectionMatrix:zeroToOneOrtho];

    SDSimpleEffect *effect = [SDEffectsManager simpleEffect];
    [effect prepareToDraw];
    
    for (int crazy = 0; crazy < 10; crazy++)
    {
        int numLines = 10000;
        GLKVector3 vertices[numLines * 2];
        GLKVector4 colors[numLines * 2];
        for (int i = 0; i < numLines; i++)
        {
            GLKVector3 position = [SDGLKitHelper randomGLKVector3];
            GLKVector3 vector = GLKVector3MultiplyScalar([SDGLKitHelper randomGLKVector3], 0.01);
            
            vertices[i * 2 + 0] = position;
            vertices[i * 2 + 1] = GLKVector3Add(position, vector);
            
//            float brightness = powf((arc4random() / (float)0x100000000), 0.5);
            float brightness = powf((arc4random() / (float)0x100000000), 1);
            
            colors[i * 2 + 0] = GLKVector4Make((arc4random() / (float)0x100000000), (arc4random() / (float)0x100000000), (arc4random() / (float)0x100000000), brightness);
            colors[i * 2 + 1] = GLKVector4Make((arc4random() / (float)0x100000000), (arc4random() / (float)0x100000000), (arc4random() / (float)0x100000000), brightness);
        }
        
        glEnable(GL_BLEND);
        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_DST_ALPHA);
        
        glEnableVertexAttribArray(effect.positionVertexAttribute);
        glEnableVertexAttribArray(effect.colorVertexAttribute);
        glVertexAttribPointer(effect.positionVertexAttribute, 3, GL_FLOAT, GL_FALSE, 0, vertices);
        glVertexAttribPointer(effect.colorVertexAttribute, 4, GL_FLOAT, GL_FALSE, 0, colors);
        glDrawArrays(GL_LINES, 0, numLines);
        glDisableVertexAttribArray(effect.colorVertexAttribute);
        glDisableVertexAttribArray(effect.positionVertexAttribute);
        
        glDisable(GL_BLEND);
    }
    
    glBindFramebuffer(GL_FRAMEBUFFER, 0);
    GetGLError();
    glBindRenderbuffer(GL_RENDERBUFFER, 0);
    GetGLError();
    
    glBindTexture(GL_TEXTURE_2D, texture);
    GetGLError();
    
    NSLog(@"texture id: %d", texture);
}

- (void)tearDownGL
{
    [EAGLContext setCurrentContext:self.glContext];
    
    [SDEffectsManager destroySharedEffectsManager];
}

#pragma mark - GLKView and GLKViewController delegate methods

- (void)update
{
    GLKMatrix4 orthoMatrix = GLKMatrix4MakeOrtho(-scaleFactor + xOffset, scaleFactor + xOffset,
                                                 -scaleFactor / 2, scaleFactor * 1.5,
                                                 -10.0, 10.0);
    
    [SDEffectsManager setProjectionMatrix:orthoMatrix];
    
    for (SDCreature *creature in world.livingCreatures)
    {
        [creature update];

        // Kill creatures that are exploding
        if (creature.exploding)
        {
            [creature destroyPhysicsRepresentation];
        }
        
        // Kill creatures that fall off the screen
        GLKVector2 centroid = creature.centroid;
        if (centroid.x < -scaleFactor + xOffset || centroid.x > scaleFactor + xOffset || centroid.y < -scaleFactor)
        {
            [creature destroyPhysicsRepresentation];
        }
    }
    
    [world updateWithTimeElapsed:self.timeSinceLastUpdate];
}

- (void)glkView:(GLKView *)view drawInRect:(CGRect)rect
{
    [world draw];
    
    [SDEffectsManager setModelViewMatrix:GLKMatrix4Identity];
    
    for (SDCreature *creature in world.livingCreatures)
    {
#warning TODO(mrotondo): If the terrain is displaced in z or anything, displace the creature as well.
        [creature draw];
    }
    
    for (SDCreature *creature in creaturesBeingDrawn)
    {
        [creature draw];
    }
}

#pragma mark - MFTransactionObserverDelegate

- (void)createdObject:(NSManagedObject *)object
{
    if ([object isKindOfClass:[SDCreature class]]) 
    {
        SDCreature *creature = (SDCreature *)object;
        
        [[world currentTerrain] addCreaturesObject:creature];
        [creaturesBeingDrawn addObject:creature];
    }
}

-(void)completedObject:(NSManagedObject *)object
{
    if ([object isKindOfClass:[SDCreature class]])
    {
        SDCreature *creature = (SDCreature *)object;
        
        if (!creature.terrain)
        {
            NSLog(@"Got a creature with no world from an alternate history. Dying.");
            return;
        }
        
        [creature createPhysicsRepresentation];  
        [creaturesBeingDrawn removeObject:creature];
        
        // Population control: Kill off creatures until we have at most 8 alive
        // (This should only ever happen once per newly-added creature, but just in case, we loop)
        while ([world.livingCreatures count] > 8)
        {
            SDCreature *oldestCreature = [world.livingCreatures objectAtIndex:0];
            [oldestCreature destroyPhysicsRepresentation];
        }
    }
}

@end
