//
//  SDCreatureSound.m
//  SpringDudes
//
//  Created by Luke Iannini on 3/4/12.
//  Copyright (c) 2012 Rototyping. All rights reserved.
//

#import "SDCreatureSound.h"
#import "SCKit.h"
#import "SDWorldSound.h"

float mtof(float f);
float mtof(float f)
{
    if (f <= -1500) return(0);
    else if (f > 1499) return(mtof(1499));
    else return (8.17579891564 * exp(.0577622650 * f));
}

@interface SDCreatureSound ()

- (NSInteger)midiNumberForFloat:(float)aFloat;
- (RSGraph *)randomGraph;

+ (SCGroup *)creatureSoundGroup;

@end

@implementation SDCreatureSound
{
    RSGraph *graph;
    RSWire *outputWire;
}

+ (SCGroup *)creatureSoundGroup
{
    static SCGroup *creatureSoundGroup;
    if (!creatureSoundGroup) 
    {
        creatureSoundGroup = [SCGroup group];
    }
    return creatureSoundGroup;
}


+ (SDCreatureSound *)creatureSound
{
    return [[self alloc] init];
}

- (id)init
{
    self = [super init];
    if (self) 
    {
        [self createSynthGraph];
    }
    return self;
}

- (void)dealloc
{
    [graph.managedObjectContext deleteObject:graph];
}

- (void)createSynthGraph
{
    graph = [[self randomGraph] graphCopy];
    
    [self carrierFreq].centerValueValue = 200;
    [self filterFreq].centerValueValue = 200;
    
    [[graph nodeWithID:@"vibrato"] controlNamed:@"freq"].centerValueValue = arc4random() % 10;
    [[graph nodeWithID:@"filter"] controlNamed:@"rq"].centerValueValue = 4.0f;
    
    CGFloat randomFloat = ((CGFloat)arc4random() / 0x100000000);
    graph.lagTime = pow(randomFloat / 2, 3);
    
    [SCBundle bundleMessages:^{
        graph.superGroup = [[self class] creatureSoundGroup];
        outputWire = [RSWire wireFrom:graph.outNode to:[[SDWorldSound defaultWorldSound] input] atAmp:9.0f];
        [graph spawn];
        //[graph connectOutToBus:[SCBus mainOutputBus]];
        
    }];
}

- (void)freeSynthGraph
{
    [graph free];
    [graph.managedObjectContext deleteObject:graph];
    graph = nil;
}

- (RSGraph *)randomGraph
{
    Pulsar *pulsar = [Pulsar sharedPulsar];
    
    NSArray *carrierTypes = [NSArray arrayWithObjects:@"Pulse-AR", @"Saw-AR", @"SinOsc-AR", nil];
    NSUInteger choice1 = arc4random() % [carrierTypes count];
    NSString *carrierSynthName = [carrierTypes objectAtIndex:choice1];
    
    NSArray *vibratoTypes = [NSArray arrayWithObjects:@"Pulse-KR", @"Saw-KR", @"SinOsc-KR", nil];
    NSUInteger choice2 = arc4random() % [vibratoTypes count];
    NSString *vibratoSynthName = [vibratoTypes objectAtIndex:choice2];
    
    NSString *graphName = [NSString stringWithFormat:@"SpringDudeSound%i%i", choice1, choice2];
    
    return [pulsar graphNamed:graphName creation:^(RSGraph *newGraph) {
        
        RSNode *carrier = [newGraph addNodeWithID:@"carrier" fromSynthDefNamed:carrierSynthName];
        RSNode *filter = [newGraph addNodeWithID:@"filter" fromSynthDefNamed:@"LPF-AR"];
        RSNode *envNode = [newGraph addNodeWithID:@"envelope" fromSynthDefNamed:@"Linen-KR"];
        RSNode *mulNode = [newGraph addNodeFromSynthDef:[pulsar synthDefNamed:@"*-AR"]];
        
        [RSWire wireFrom:carrier to:[filter controlNamed:@"a_in"] atAmp:1.0f];
        [RSWire wireFrom:filter to:[mulNode controlNamed:@"a_in"] atAmp:1.0f];
        [RSWire wireFrom:envNode to:[mulNode controlNamed:@"value"] atAmp:1.0f];
        [RSWire wireFrom:mulNode to:[newGraph.outNode controlNamed:@"a_in"] atAmp:0.1f];
        
        // Vibrato
        RSNode *vibSin = [newGraph addNodeWithID:@"vibrato" fromSynthDefNamed:vibratoSynthName];
        [vibSin controlNamed:@"freq"].centerValueValue = 7;
        [RSWire wireFrom:vibSin to:[carrier controlNamed:@"freq"] atAmp:3];
        
        [envNode controlNamed:@"releaseTime"].centerValueValue = 0.0f;
        
        newGraph.lagTime = 0.0f;
    }];
}

- (RSInput *)gate
{
    return [[graph nodeWithID:@"envelope"] controlNamed:@"gate"];
}

- (void)setPulseFreqToMajorScaleFromFloat:(float)aFloat
{
    [self setPulseFreqToNote:[self midiNumberForFloat:aFloat]];
}

- (void)setPulseFreqToNote:(float)note
{
    [self carrierFreq].centerValueValue = mtof(note);
}

- (void)setAmp:(float)amp
{
    outputWire.ampValue = amp;
}

- (RSInput *)carrierFreq
{
    return [[graph nodeWithID:@"carrier"] controlNamed:@"freq"];
}

- (RSInput *)filterFreq
{
    return [[graph nodeWithID:@"filter"] controlNamed:@"freq"];
}

- (NSInteger)midiNumberForFloat:(float)aFloat
{
    float minMaxedFloat = MAX(0, MIN(aFloat, 1));
    NSArray *majorScale = [[self class] majorScale];
    NSInteger index = (([majorScale count] - 1) * minMaxedFloat);
    return [[majorScale objectAtIndex:index] integerValue];
}

+ (NSArray *)majorScale
{
    static NSMutableArray *notes = nil;
    static NSUInteger majorNotes[] = {0, 2, 4, 5, 7, 9, 11};
    
    if (!notes) 
    {
        notes = [NSMutableArray array];
        for (NSUInteger octave = 3; octave < 8; octave++) 
        {
            for (NSUInteger degree = 0; degree < 7; degree++) 
            {
                NSUInteger note = octave * 12 + majorNotes[degree];
                [notes addObject:[NSNumber numberWithInt:note]];
            }
        }
    }
    return notes;
}

@end
