//
//  SDCreature+Convenience.m
//  SpringDudes
//
//  Created by Michael Rotondo on 3/7/12.
//  Copyright (c) 2012 Rototyping. All rights reserved.
//

#import "SDCreature+Convenience.h"

@implementation SDCreature (Convenience)

- (GLKVector3)primaryColor
{
    GLKVector3 color;
    [self.primaryColorData getBytes:&color length:sizeof(GLKVector3)];
    return color;
}

- (void)setPrimaryColor:(GLKVector3)primaryColor
{
    self.primaryColorData = [NSData dataWithBytes:&primaryColor length:sizeof(GLKVector3)];
}

- (GLKVector3)secondaryColor
{
    GLKVector3 color;
    [self.secondaryColorData getBytes:&color length:sizeof(GLKVector3)];
    return color;
}

- (void)setSecondaryColor:(GLKVector3)secondaryColor
{
    self.secondaryColorData = [NSData dataWithBytes:&secondaryColor length:sizeof(GLKVector3)];
}

- (GLKVector2)origin
{
    GLKVector2 point;
    [self.originData getBytes:&point length:sizeof(GLKVector2)];
    return point;
}

- (void)setOrigin:(GLKVector2)origin
{
    self.originData = [NSData dataWithBytes:&origin length:sizeof(GLKVector2)];
}

@end
