//
//  SDWorldState.m
//  SpringDudes
//
//  Created by Michael Rotondo on 3/19/12.
//  Copyright (c) 2012 Rototyping. All rights reserved.
//

#import "SDWorldState.h"

@implementation SDWorldState
{
    NSTimeInterval time;
}

- (void)updateWithTimeElapsed:(NSTimeInterval)timeElapsed
{
    time += timeElapsed;
}

- (float)sunAngle
{
    return 0.25f * time;
}

- (GLKVector3)skyColor
{
    GLKVector3 daytimeColor = GLKVector3Make(0.15, 0.45, 0.95);
    GLKVector3 nightTimeColor = GLKVector3Make(0.01, 0.05, 0.2);
    GLKVector3 dawnColor = GLKVector3Make(0.3, 0.2, 0.1);
    GLKVector3 duskColor = GLKVector3Make(0.05, 0.01, 0.1);
    float brightness = sinf(self.sunAngle) / 2.0f + 0.5f;
    GLKVector3 dayNightColor = GLKVector3Add(nightTimeColor, GLKVector3MultiplyScalar(GLKVector3Subtract(daytimeColor, nightTimeColor), brightness));
    float dawnAmount = cosf(self.sunAngle) / 2.0f + 0.5f;
    GLKVector3 dawnFactor = GLKVector3MultiplyScalar(dawnColor, dawnAmount);
    float duskAmount = cosf(self.moonAngle) / 2.0f + 0.5f;
    GLKVector3 duskFactor = GLKVector3MultiplyScalar(duskColor, duskAmount);
    GLKVector3 dawnDuskColor = GLKVector3Add(dawnFactor, duskFactor);
    return GLKVector3Add(dayNightColor, dawnDuskColor);
}

- (GLKVector3)sunDiffuseColor
{
    GLKVector3 dayColor = GLKVector3MultiplyScalar(GLKVector3Make(1.0f, 0.95f, 0.9f), MAX(0, sinf(self.sunAngle)));
    GLKVector3 dawnColor = GLKVector3MultiplyScalar(GLKVector3Make(0.7, 0.3, 0.5), MAX(0, cosf(self.sunAngle)));
    return GLKVector3Add(dayColor, dawnColor);
}

- (GLKVector3)sunSpecularColor
{
    return GLKVector3MultiplyScalar(GLKVector3Make(0.9f, 0.9f, 0.9f), MAX(0, sinf(self.sunAngle)));
}

- (float)moonAngle
{
    return self.sunAngle + M_PI;
}

- (GLKVector3)moonDiffuseColor
{
    GLKVector3 nightColor = GLKVector3MultiplyScalar(GLKVector3Make(0.5f, 0.55f, 0.9f), MAX(0, sinf(self.moonAngle)));
    GLKVector3 duskColor = GLKVector3MultiplyScalar(GLKVector3Make(0.5, 0.2, 0.4), MAX(0, cosf(self.moonAngle)));
    return GLKVector3Add(nightColor, duskColor);
}

- (GLKVector3)moonSpecularColor
{
    return GLKVector3MultiplyScalar(GLKVector3Make(0.1f, 0.1f, 0.7f), MAX(0, sinf(self.moonAngle)));
}

@end
