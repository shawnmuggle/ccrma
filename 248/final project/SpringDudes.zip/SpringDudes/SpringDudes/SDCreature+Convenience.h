//
//  SDCreature+Convenience.h
//  SpringDudes
//
//  Created by Michael Rotondo on 3/7/12.
//  Copyright (c) 2012 Rototyping. All rights reserved.
//

#import "SDCreature.h"

@interface SDCreature (Convenience)

@property (nonatomic) GLKVector3 primaryColor;
@property (nonatomic) GLKVector3 secondaryColor;
@property (nonatomic) GLKVector2 origin;

@end
