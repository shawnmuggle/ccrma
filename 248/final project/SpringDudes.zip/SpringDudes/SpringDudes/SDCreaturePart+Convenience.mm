//
//  SDCreaturePart+Convenience.m
//  SpringDudes
//
//  Created by Michael Rotondo on 3/7/12.
//  Copyright (c) 2012 Rototyping. All rights reserved.
//

#import "SDCreaturePart+Convenience.h"

@implementation SDCreaturePart (Convenience)

- (GLKVector3)primaryColor
{
    GLKVector3 color;
    [self.primaryColorData getBytes:&color length:sizeof(GLKVector3)];
    return color;
}

- (void)setPrimaryColor:(GLKVector3)primaryColor
{
    self.primaryColorData = [NSData dataWithBytes:&primaryColor length:sizeof(GLKVector3)];
}

- (GLKVector3)secondaryColor
{
    GLKVector3 color;
    [self.secondaryColorData getBytes:&color length:sizeof(GLKVector3)];
    return color;
}

- (void)setSecondaryColor:(GLKVector3)secondaryColor
{
    self.secondaryColorData = [NSData dataWithBytes:&secondaryColor length:sizeof(GLKVector3)];
}

- (GLKVector2)originalPosition
{
    GLKVector2 point;
    [self.originalPositionData getBytes:&point length:sizeof(GLKVector2)];
    return point;
}

- (void)setOriginalPosition:(GLKVector2)originalPosition
{
    self.originalPositionData = [NSData dataWithBytes:&originalPosition length:sizeof(GLKVector2)];
}

@end
