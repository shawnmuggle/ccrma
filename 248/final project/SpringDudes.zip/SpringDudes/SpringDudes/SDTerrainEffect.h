//
//  SDDayNightEffect.h
//  SpringDudes
//
//  Created by Luke Iannini on 3/11/12.
//  Copyright (c) 2012 Rototyping. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SDTerrainEffect : NSObject <GLKNamedEffect>

@property (nonatomic, strong) GLKEffectPropertyTransform *transform;
@property (nonatomic, strong) GLKEffectPropertyTexture *diffuseTexture;
@property (nonatomic) GLuint positionVertexAttribute;
@property (nonatomic) GLuint normalVertexAttribute;
@property (nonatomic) GLuint texCoordVertexAttribute;

@property (nonatomic) GLKVector3 sunPosition;
@property (nonatomic) GLKVector3 sunDiffuseColor;
@property (nonatomic) GLKVector3 sunSpecularColor;
@property (nonatomic) GLKVector3 moonPosition;
@property (nonatomic) GLKVector3 moonDiffuseColor;
@property (nonatomic) GLKVector3 moonSpecularColor;

@end
