//
//  SDSimpleEffect.m
//  SpringDudes
//
//  Created by Luke Iannini on 3/11/12.
//  Copyright (c) 2012 Rototyping. All rights reserved.
//

#import "SDTerrainEffect.h"
#import "sourceUtil.h"
#import "ShaderProgramLoader.h"

@implementation SDTerrainEffect
{
    GLuint programName;
    
    GLint modelViewMatrixUniformIdx;
    GLint projectionMatrixUniformIdx;
    GLint normalMatrixUniformIdx;
    
    GLint diffuseTextureUniformIdx;
    
    GLint sunPositionUniformIdx;
    GLint sunDiffuseColorUniformIdx;
    GLint sunSpecularColorUniformIdx;

    GLint moonPositionUniformIdx;
    GLint moonDiffuseColorUniformIdx;
    GLint moonSpecularColorUniformIdx;
}

- (id)init
{
    self = [super init];
    if (self)
    {
        //////////////////////////////////////////
		// Load and Setup shaders for rendering //
		//////////////////////////////////////////
		
		demoSource *vtxSource = NULL;
		demoSource *frgSource = NULL;
        NSString *filePathName;
		
		filePathName = [[NSBundle mainBundle] pathForResource:@"terrain" ofType:@"vsh"];
		vtxSource = srcLoadSource([filePathName cStringUsingEncoding:NSASCIIStringEncoding]);
		
		filePathName = [[NSBundle mainBundle] pathForResource:@"terrain" ofType:@"fsh"];
		frgSource = srcLoadSource([filePathName cStringUsingEncoding:NSASCIIStringEncoding]);
		
		// Build Program
		programName = [ShaderProgramLoader buildProgramWithVertexSource:vtxSource
                                                     withFragmentSource:frgSource
                                                              withColor:NO
                                                             withNormal:YES
                                                           withTexCoord:YES];
		
		srcDestroySource(vtxSource);
		srcDestroySource(frgSource);
		
        [self registerUniform:@"modelViewMatrix" atLocation:&modelViewMatrixUniformIdx];
        [self registerUniform:@"projectionMatrix" atLocation:&projectionMatrixUniformIdx];
        [self registerUniform:@"normalMatrix" atLocation:&normalMatrixUniformIdx];

        [self registerUniform:@"diffuseMap" atLocation:&diffuseTextureUniformIdx];
        
        [self registerUniform:@"sunPosition" atLocation:&sunPositionUniformIdx];
        [self registerUniform:@"sunDiffuseColor" atLocation:&sunDiffuseColorUniformIdx];
        [self registerUniform:@"sunSpecularColor" atLocation:&sunSpecularColorUniformIdx];

        [self registerUniform:@"moonPosition" atLocation:&moonPositionUniformIdx];
        [self registerUniform:@"moonDiffuseColor" atLocation:&moonDiffuseColorUniformIdx];
        [self registerUniform:@"moonSpecularColor" atLocation:&moonSpecularColorUniformIdx];
        
        self.transform = [[GLKEffectPropertyTransform alloc] init];
        
        self.diffuseTexture = [[GLKEffectPropertyTexture alloc] init];
        
        // These are determined in the ShaderProgramLoader buildProgram method
        self.positionVertexAttribute = POS_ATTRIB_IDX;
        self.normalVertexAttribute = NORMAL_ATTRIB_IDX;
        self.texCoordVertexAttribute = TEXCOORD_ATTRIB_IDX;
    }
    return self;
}

- (void) dealloc
{
	[ShaderProgramLoader destroyProgram:programName];
}

- (void)registerUniform:(NSString *)uniformName atLocation:(GLint *)uniformLocation
{
    *uniformLocation = glGetUniformLocation(programName, [uniformName UTF8String]);
    
    if (*uniformLocation < 0)
    {
        NSLog(@"No %@ in shader %@", uniformName, self);
    }
}

- (void)prepareToDraw
{
    // Use the program for rendering the world
	glUseProgram(programName);

    // Have our shader use the modelview & projection matrices that we calculated above
    glUniformMatrix4fv(projectionMatrixUniformIdx, 1, GL_FALSE, self.transform.projectionMatrix.m);
	glUniformMatrix4fv(modelViewMatrixUniformIdx, 1, GL_FALSE, self.transform.modelviewMatrix.m);
    glUniformMatrix3fv(normalMatrixUniformIdx, 1, GL_FALSE, self.transform.normalMatrix.m);

    glUniform3fv(sunPositionUniformIdx, 1, self.sunPosition.v);
    glUniform3fv(sunDiffuseColorUniformIdx, 1, self.sunDiffuseColor.v);
    glUniform3fv(sunSpecularColorUniformIdx, 1, self.sunSpecularColor.v);

    glUniform3fv(moonPositionUniformIdx, 1, self.moonPosition.v);
    glUniform3fv(moonDiffuseColorUniformIdx, 1, self.moonDiffuseColor.v);
    glUniform3fv(moonSpecularColorUniformIdx, 1, self.moonSpecularColor.v);
    
    glActiveTexture(GL_TEXTURE7);
    glBindTexture(GL_TEXTURE_2D, 1);
    glUniform1i(diffuseTextureUniformIdx, self.diffuseTexture.name);
}

@end
