//
//  SDSimpleEffect.h
//  SpringDudes
//
//  Created by Luke Iannini on 3/11/12.
//  Copyright (c) 2012 Rototyping. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SDSimpleEffect : NSObject <GLKNamedEffect>

@property (nonatomic, strong) GLKEffectPropertyTransform *transform;
@property (nonatomic) GLuint positionVertexAttribute;
@property (nonatomic) GLuint colorVertexAttribute;

@end
