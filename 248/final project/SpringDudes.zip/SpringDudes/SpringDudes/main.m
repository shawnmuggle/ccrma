//
//  main.m
//  SpringDudes
//
//  Created by Michael Rotondo on 2/19/12.
//  Copyright (c) 2012 Rototyping. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "SDAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([SDAppDelegate class]));
    }
}
