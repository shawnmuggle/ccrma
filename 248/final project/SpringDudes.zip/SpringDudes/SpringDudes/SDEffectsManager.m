//
//  SDEffectsManager.m
//  SpringDudes
//
//  Created by Michael Rotondo on 3/18/12.
//  Copyright (c) 2012 Rototyping. All rights reserved.
//

#import "SDEffectsManager.h"
#import "SDSimpleEffect.h"
#import "SDCreaturePartEffect.h"
#import "SDTerrainEffect.h"

static SDEffectsManager *sharedEffectsManager;

@implementation SDEffectsManager
{
    NSDictionary *effects;
}

+ (SDEffectsManager *)sharedEffectsManager
{
    return sharedEffectsManager;
}

+ (void)initializeSharedEffectsManager
{
    sharedEffectsManager = [[SDEffectsManager alloc] init];
}

+ (void)destroySharedEffectsManager
{
    sharedEffectsManager = nil;
}

+ (SDSimpleEffect *)simpleEffect
{
    return (SDSimpleEffect *)[sharedEffectsManager effect:SDSimpleEffectID];
}

+ (SDCreaturePartEffect *)creaturePartEffect
{
    return (SDCreaturePartEffect *)[sharedEffectsManager effect:SDCreaturePartEffectID];
}

+ (SDTerrainEffect *)terrainEffect
{
    return (SDTerrainEffect *)[sharedEffectsManager effect:SDTerrainEffectID];
}

+ (void)setProjectionMatrix:(GLKMatrix4)projectionMatrix
{
    [self simpleEffect].transform.projectionMatrix = projectionMatrix;
    [self creaturePartEffect].transform.projectionMatrix = projectionMatrix;
    [self terrainEffect].transform.projectionMatrix = projectionMatrix;
}

+ (void)setModelViewMatrix:(GLKMatrix4)modelViewMatrix
{
    [self simpleEffect].transform.modelviewMatrix = modelViewMatrix;
    [self creaturePartEffect].transform.modelviewMatrix = modelViewMatrix;
    [self terrainEffect].transform.modelviewMatrix = modelViewMatrix;
}

- (id)init
{
    self = [super init];
    if (self)
    {
        effects = @{
    SDSimpleEffectID:[[SDSimpleEffect alloc] init],
    SDCreaturePartEffectID:[[SDCreaturePartEffect alloc] init],
    SDTerrainEffectID:[[SDTerrainEffect alloc] init]
        };
    }
    return self;
}

- (id<GLKNamedEffect>)effect:(NSString *)effectID
{
    return [effects objectForKey:effectID];
}

@end
