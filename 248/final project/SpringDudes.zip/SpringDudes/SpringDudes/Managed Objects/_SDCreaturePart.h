// DO NOT EDIT. This file is machine-generated and constantly overwritten.
// Make changes to SDCreaturePart.h instead.

#import <CoreData/CoreData.h>


extern const struct SDCreaturePartAttributes {
	__unsafe_unretained NSString *numSides;
	__unsafe_unretained NSString *originalPositionData;
	__unsafe_unretained NSString *primaryColorData;
	__unsafe_unretained NSString *radius;
	__unsafe_unretained NSString *secondaryColorData;
	__unsafe_unretained NSString *uniqueID;
} SDCreaturePartAttributes;

extern const struct SDCreaturePartRelationships {
	__unsafe_unretained NSString *connections;
	__unsafe_unretained NSString *creature;
} SDCreaturePartRelationships;

extern const struct SDCreaturePartFetchedProperties {
} SDCreaturePartFetchedProperties;

@class SDCreaturePartConnection;
@class SDCreature;








@interface SDCreaturePartID : NSManagedObjectID {}
@end

@interface _SDCreaturePart : NSManagedObject {}
+ (id)insertInManagedObjectContext:(NSManagedObjectContext*)moc_;
+ (NSString*)entityName;
+ (NSEntityDescription*)entityInManagedObjectContext:(NSManagedObjectContext*)moc_;
- (SDCreaturePartID*)objectID;




@property (nonatomic, strong) NSNumber *numSides;


@property int16_t numSidesValue;
- (int16_t)numSidesValue;
- (void)setNumSidesValue:(int16_t)value_;

//- (BOOL)validateNumSides:(id*)value_ error:(NSError**)error_;




@property (nonatomic, strong) NSData *originalPositionData;


//- (BOOL)validateOriginalPositionData:(id*)value_ error:(NSError**)error_;




@property (nonatomic, strong) NSData *primaryColorData;


//- (BOOL)validatePrimaryColorData:(id*)value_ error:(NSError**)error_;




@property (nonatomic, strong) NSNumber *radius;


@property float radiusValue;
- (float)radiusValue;
- (void)setRadiusValue:(float)value_;

//- (BOOL)validateRadius:(id*)value_ error:(NSError**)error_;




@property (nonatomic, strong) NSData *secondaryColorData;


//- (BOOL)validateSecondaryColorData:(id*)value_ error:(NSError**)error_;




@property (nonatomic, strong) NSString *uniqueID;


//- (BOOL)validateUniqueID:(id*)value_ error:(NSError**)error_;





@property (nonatomic, strong) NSSet* connections;

- (NSMutableSet*)connectionsSet;




@property (nonatomic, strong) SDCreature* creature;

//- (BOOL)validateCreature:(id*)value_ error:(NSError**)error_;





@end

@interface _SDCreaturePart (CoreDataGeneratedAccessors)

- (void)addConnections:(NSSet*)value_;
- (void)removeConnections:(NSSet*)value_;
- (void)addConnectionsObject:(SDCreaturePartConnection*)value_;
- (void)removeConnectionsObject:(SDCreaturePartConnection*)value_;

@end

@interface _SDCreaturePart (CoreDataGeneratedPrimitiveAccessors)


- (NSNumber *)primitiveNumSides;
- (void)setPrimitiveNumSides:(NSNumber *)value;

- (int16_t)primitiveNumSidesValue;
- (void)setPrimitiveNumSidesValue:(int16_t)value_;




- (NSData *)primitiveOriginalPositionData;
- (void)setPrimitiveOriginalPositionData:(NSData *)value;




- (NSData *)primitivePrimaryColorData;
- (void)setPrimitivePrimaryColorData:(NSData *)value;




- (NSNumber *)primitiveRadius;
- (void)setPrimitiveRadius:(NSNumber *)value;

- (float)primitiveRadiusValue;
- (void)setPrimitiveRadiusValue:(float)value_;




- (NSData *)primitiveSecondaryColorData;
- (void)setPrimitiveSecondaryColorData:(NSData *)value;




- (NSString *)primitiveUniqueID;
- (void)setPrimitiveUniqueID:(NSString *)value;





- (NSMutableSet*)primitiveConnections;
- (void)setPrimitiveConnections:(NSMutableSet*)value;



- (SDCreature*)primitiveCreature;
- (void)setPrimitiveCreature:(SDCreature*)value;


@end
