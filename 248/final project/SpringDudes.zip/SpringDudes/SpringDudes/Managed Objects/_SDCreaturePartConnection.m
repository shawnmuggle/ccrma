// DO NOT EDIT. This file is machine-generated and constantly overwritten.
// Make changes to SDCreaturePartConnection.m instead.

#import "_SDCreaturePartConnection.h"

const struct SDCreaturePartConnectionAttributes SDCreaturePartConnectionAttributes = {
};

const struct SDCreaturePartConnectionRelationships SDCreaturePartConnectionRelationships = {
	.parts = @"parts",
};

const struct SDCreaturePartConnectionFetchedProperties SDCreaturePartConnectionFetchedProperties = {
};

@implementation SDCreaturePartConnectionID
@end

@implementation _SDCreaturePartConnection

+ (id)insertInManagedObjectContext:(NSManagedObjectContext*)moc_ {
	NSParameterAssert(moc_);
	return [NSEntityDescription insertNewObjectForEntityForName:@"SDCreaturePartConnection" inManagedObjectContext:moc_];
}

+ (NSString*)entityName {
	return @"SDCreaturePartConnection";
}

+ (NSEntityDescription*)entityInManagedObjectContext:(NSManagedObjectContext*)moc_ {
	NSParameterAssert(moc_);
	return [NSEntityDescription entityForName:@"SDCreaturePartConnection" inManagedObjectContext:moc_];
}

- (SDCreaturePartConnectionID*)objectID {
	return (SDCreaturePartConnectionID*)[super objectID];
}

+ (NSSet *)keyPathsForValuesAffectingValueForKey:(NSString *)key {
	NSSet *keyPaths = [super keyPathsForValuesAffectingValueForKey:key];
	

	return keyPaths;
}




@dynamic parts;

	
- (NSMutableSet*)partsSet {
	[self willAccessValueForKey:@"parts"];
  
	NSMutableSet *result = (NSMutableSet*)[self mutableSetValueForKey:@"parts"];
  
	[self didAccessValueForKey:@"parts"];
	return result;
}
	






@end
