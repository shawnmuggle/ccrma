#import "_SDWorld.h"

@class SDTerrainEffect;

@interface SDWorld : _SDWorld {}

+ (SDWorld *)singletonWorldInManagedObjectContext:(NSManagedObjectContext *)managedObjectContext;
- (void)initializeWithWidth:(float)width andXOffset:(float)xOffset;
- (void)updateWithTimeElapsed:(NSTimeInterval)timeElapsed;
- (SDWorldTerrain *)currentTerrain;
- (void)draw;

@property (nonatomic) BOOL initialized;
@property (nonatomic, strong, readonly) NSArray *livingCreatures;

@end
