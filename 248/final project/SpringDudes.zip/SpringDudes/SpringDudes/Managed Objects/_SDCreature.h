// DO NOT EDIT. This file is machine-generated and constantly overwritten.
// Make changes to SDCreature.h instead.

#import <CoreData/CoreData.h>


extern const struct SDCreatureAttributes {
	__unsafe_unretained NSString *dateCreated;
	__unsafe_unretained NSString *originData;
	__unsafe_unretained NSString *primaryColorData;
	__unsafe_unretained NSString *secondaryColorData;
	__unsafe_unretained NSString *uniqueID;
} SDCreatureAttributes;

extern const struct SDCreatureRelationships {
	__unsafe_unretained NSString *parts;
	__unsafe_unretained NSString *terrain;
} SDCreatureRelationships;

extern const struct SDCreatureFetchedProperties {
} SDCreatureFetchedProperties;

@class SDCreaturePart;
@class SDWorldTerrain;







@interface SDCreatureID : NSManagedObjectID {}
@end

@interface _SDCreature : NSManagedObject {}
+ (id)insertInManagedObjectContext:(NSManagedObjectContext*)moc_;
+ (NSString*)entityName;
+ (NSEntityDescription*)entityInManagedObjectContext:(NSManagedObjectContext*)moc_;
- (SDCreatureID*)objectID;




@property (nonatomic, strong) NSDate *dateCreated;


//- (BOOL)validateDateCreated:(id*)value_ error:(NSError**)error_;




@property (nonatomic, strong) NSData *originData;


//- (BOOL)validateOriginData:(id*)value_ error:(NSError**)error_;




@property (nonatomic, strong) NSData *primaryColorData;


//- (BOOL)validatePrimaryColorData:(id*)value_ error:(NSError**)error_;




@property (nonatomic, strong) NSData *secondaryColorData;


//- (BOOL)validateSecondaryColorData:(id*)value_ error:(NSError**)error_;




@property (nonatomic, strong) NSString *uniqueID;


//- (BOOL)validateUniqueID:(id*)value_ error:(NSError**)error_;





@property (nonatomic, strong) NSOrderedSet* parts;

- (NSMutableOrderedSet*)partsSet;




@property (nonatomic, strong) SDWorldTerrain* terrain;

//- (BOOL)validateTerrain:(id*)value_ error:(NSError**)error_;





@end

@interface _SDCreature (CoreDataGeneratedAccessors)

- (void)addParts:(NSOrderedSet*)value_;
- (void)removeParts:(NSOrderedSet*)value_;
- (void)addPartsObject:(SDCreaturePart*)value_;
- (void)removePartsObject:(SDCreaturePart*)value_;

@end

@interface _SDCreature (CoreDataGeneratedPrimitiveAccessors)


- (NSDate *)primitiveDateCreated;
- (void)setPrimitiveDateCreated:(NSDate *)value;




- (NSData *)primitiveOriginData;
- (void)setPrimitiveOriginData:(NSData *)value;




- (NSData *)primitivePrimaryColorData;
- (void)setPrimitivePrimaryColorData:(NSData *)value;




- (NSData *)primitiveSecondaryColorData;
- (void)setPrimitiveSecondaryColorData:(NSData *)value;




- (NSString *)primitiveUniqueID;
- (void)setPrimitiveUniqueID:(NSString *)value;





- (NSMutableOrderedSet*)primitiveParts;
- (void)setPrimitiveParts:(NSMutableOrderedSet*)value;



- (SDWorldTerrain*)primitiveTerrain;
- (void)setPrimitiveTerrain:(SDWorldTerrain*)value;


@end
