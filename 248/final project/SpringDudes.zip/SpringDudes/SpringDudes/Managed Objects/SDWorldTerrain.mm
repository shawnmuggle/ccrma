#import "SDWorld.h"
#import "SDWorldTerrain.h"
#import <Box2D/Box2D.h>
#import "SDBezierPoint.h"
#import "SDTerrainEffect.h"
#import "SDEffectsManager.h"

#define NUM_TERRAIN_POINTS 21
#define TERRAIN_SEGMENT_WIDTH 1.0f
#define INTERPOLATION_SPACING 0.1f

@interface SDWorldTerrain ()

- (void)generateVertices;
- (void)interpolateVertices;

@end

@implementation SDWorldTerrain
{
    SDBezierPoint *firstPoint;
        
    NSMutableSet *terrainVertices;
    
    b2ChainShape *physicsShape;
    b2Body *physicsBody;
}
@synthesize physicsWorld;

- (void)initializeWithWidth:(float)width andXOffset:(float)xOffset
{    
    unsigned int numTerrainPoints = width / TERRAIN_SEGMENT_WIDTH + 1;
    terrainVertices = [NSMutableSet setWithCapacity:numTerrainPoints];
    
    GLKVector2 origin = GLKVector2Make(-(width / 2.0) * TERRAIN_SEGMENT_WIDTH + xOffset, 0.0f);
    firstPoint = [[SDBezierPoint alloc] initWithPosition:origin];
    [terrainVertices addObject:firstPoint];
    SDBezierPoint *prevPoint = firstPoint;
    SDBezierPoint *newPoint;
    GLKVector2 newPosition;
    
    float variance = 1.0f;
    for (int i = 1; i < numTerrainPoints; i++)
    {
        newPosition.x = prevPoint.position.x + TERRAIN_SEGMENT_WIDTH;
        newPosition.y = prevPoint.position.y + variance * ((arc4random() / (float)0x100000000) * 2 - 1);
        
        newPoint = [[SDBezierPoint alloc] initWithPosition:newPosition];
        newPoint.prevUserPoint = prevPoint;
        
        [terrainVertices addObject:newPoint];
        
        prevPoint = newPoint;
    }
    
    [self interpolateVertices];
}

- (void)interpolateVertices
{
    SDBezierPoint *terrainPoint;
    terrainPoint = firstPoint;
    while (terrainPoint.nextUserPoint)
    {
        NSSet *interpolatedPoints = [terrainPoint bezierSubdivisionToNextPointWithSpacing:INTERPOLATION_SPACING];
        [terrainVertices unionSet:interpolatedPoints];
        terrainPoint = terrainPoint.nextUserPoint;
    }
}

- (void)createPhysicsRepresentation
{
    b2Vec2 gravity(0.0f, -7.5f);
    self.physicsWorld = new b2World(gravity);
    
    b2Vec2 *vertices = (b2Vec2 *)malloc([terrainVertices count] * sizeof(b2Vec2));
    int i = 0;
    SDBezierPoint *terrainPoint = firstPoint;
    while (terrainPoint)
    {
        vertices[i].x = terrainPoint.position.x;
        vertices[i].y = terrainPoint.position.y;
        terrainPoint = terrainPoint.nextPoint;
        i++;
    }
    
    physicsShape = new b2ChainShape();
    physicsShape->CreateChain(vertices, [terrainVertices count]);
    
    free(vertices);
    
    b2FixtureDef fd;
    fd.shape = physicsShape;
    fd.friction = 0.1f;
    
    b2BodyDef bd;
    physicsBody = self.physicsWorld->CreateBody(&bd);
    physicsBody->CreateFixture(&fd);
}

- (void)updateWithTimeElapsed:(NSTimeInterval)timeElapsed
{
    int velocityIterations = 40;
    int positionIterations = 40;
    self.physicsWorld->Step(timeElapsed, velocityIterations, positionIterations);
}

- (void)destroyPhysicsRepresentation
{
    self.physicsWorld->DestroyBody(physicsBody);
}

- (void)draw
{
    float terrainDepth = 5.0f;

#warning TODO(mrotondo): rename numTerrainVertices to something clearer
    int numTerrainVertices = physicsShape->m_count;
    int numStrips = 10;
    int numVertices = (numStrips + 1) * numTerrainVertices;
    
    GLKVector3 vertices[numVertices];
    GLKVector3 normals[numVertices];
    GLKVector2 texCoords[numVertices];
    
    for (int strip_index = 0; strip_index < numStrips + 1; strip_index++)
    {
        float percent = (float)strip_index / numStrips;
        
        for (int i = 0; i < numTerrainVertices; i++)
        {
            b2Vec2 point = physicsShape->m_vertices[i];
            int pointIndex = strip_index * numTerrainVertices + i;

            vertices[pointIndex] = GLKVector3Make(point.x,
#warning TODO(mrotondo): Refactor terrain baseline (-10 here) into a member variable
                                                  -10.0f + (point.y + 10.0f) * (1.0f - (cosf(M_PI * percent) / 2.0f + 0.5f)),
                                                  0.0f - terrainDepth * (1.0f - percent));

            texCoords[pointIndex] = GLKVector2Make((float)i / (numTerrainVertices - 1), percent);
        }
    }
    
    for (int strip_index = 0; strip_index < numStrips + 1; strip_index++)
    {
        for (int i = 0; i < numTerrainVertices; i++)
        {
            GLKVector3 leftPoint, rightPoint, lowPoint, highPoint;
            int pointIndex = strip_index * numTerrainVertices + i;
            int leftPointOffset = i > 0 ? -1 : 0;
            int rightPointOffset = i < numTerrainVertices - 1 ? 1 : 0;
            int lowPointOffset = strip_index > 0 ? -numTerrainVertices : 0;
            int highPointOffset = strip_index < numStrips ? numTerrainVertices : 0;
            leftPoint = vertices[pointIndex + leftPointOffset];
            rightPoint = vertices[pointIndex + rightPointOffset];
            lowPoint = vertices[pointIndex + lowPointOffset];
            highPoint = vertices[pointIndex + highPointOffset];
            
            GLKVector3 rightVector = GLKVector3Subtract(rightPoint, leftPoint);
            GLKVector3 uphillVector = GLKVector3Subtract(highPoint, lowPoint);
            GLKVector3 normal = GLKVector3Normalize(GLKVector3CrossProduct(uphillVector, rightVector));
            
//            NSLog(@"Normal at %d, %d is %@", i, strip_index, NSStringFromGLKVector3(normal));
            
            normals[pointIndex] = normal;
        }
    }
     SDTerrainEffect *effect = [SDEffectsManager terrainEffect];
    [effect prepareToDraw];
    
    glEnableVertexAttribArray(effect.positionVertexAttribute);
    glEnableVertexAttribArray(effect.normalVertexAttribute);
    glEnableVertexAttribArray(effect.texCoordVertexAttribute);

        glVertexAttribPointer(effect.positionVertexAttribute, 3, GL_FLOAT, GL_FALSE, 0, vertices);
    glVertexAttribPointer(effect.normalVertexAttribute, 3, GL_FLOAT, GL_FALSE, 0, normals);
    glVertexAttribPointer(effect.texCoordVertexAttribute, 2, GL_FLOAT, GL_FALSE, 0, texCoords);

    int numIndicesPerStrip = numTerrainVertices * 2 + 2;  // + 2 is so that we can create degenerate triangles
    int numIndices = numStrips * numIndicesPerStrip;
    unsigned int indices[numIndices];

    for (int strip_index = 0; strip_index < numStrips; strip_index++)
    {
        int i = 0;
        for (; i < numTerrainVertices; i++)
        {
            indices[strip_index * numIndicesPerStrip + i * 2 + 0] = strip_index * numTerrainVertices + i;
            indices[strip_index * numIndicesPerStrip + i * 2 + 1] = (strip_index + 1) * numTerrainVertices + i;
        }
        
        // Create some degenerate triangles to restart the triangle strip on the left again
        // Re-add the last vertex and the first vertex in the top row of this strip.
        indices[strip_index * numIndicesPerStrip + i * 2 + 0] = (strip_index + 1) * numTerrainVertices + numTerrainVertices - 1;
        indices[strip_index * numIndicesPerStrip + i * 2 + 1] = (strip_index + 1) * numTerrainVertices;
    }
  
    glDrawElements(GL_TRIANGLE_STRIP, numIndices, GL_UNSIGNED_INT, indices);
    
    glDisableVertexAttribArray(effect.positionVertexAttribute);
    glDisableVertexAttribArray(effect.normalVertexAttribute);
    glDisableVertexAttribArray(effect.texCoordVertexAttribute);
}

@end
