// DO NOT EDIT. This file is machine-generated and constantly overwritten.
// Make changes to SDCreature.m instead.

#import "_SDCreature.h"

const struct SDCreatureAttributes SDCreatureAttributes = {
	.dateCreated = @"dateCreated",
	.originData = @"originData",
	.primaryColorData = @"primaryColorData",
	.secondaryColorData = @"secondaryColorData",
	.uniqueID = @"uniqueID",
};

const struct SDCreatureRelationships SDCreatureRelationships = {
	.parts = @"parts",
	.terrain = @"terrain",
};

const struct SDCreatureFetchedProperties SDCreatureFetchedProperties = {
};

@implementation SDCreatureID
@end

@implementation _SDCreature

+ (id)insertInManagedObjectContext:(NSManagedObjectContext*)moc_ {
	NSParameterAssert(moc_);
	return [NSEntityDescription insertNewObjectForEntityForName:@"SDCreature" inManagedObjectContext:moc_];
}

+ (NSString*)entityName {
	return @"SDCreature";
}

+ (NSEntityDescription*)entityInManagedObjectContext:(NSManagedObjectContext*)moc_ {
	NSParameterAssert(moc_);
	return [NSEntityDescription entityForName:@"SDCreature" inManagedObjectContext:moc_];
}

- (SDCreatureID*)objectID {
	return (SDCreatureID*)[super objectID];
}

+ (NSSet *)keyPathsForValuesAffectingValueForKey:(NSString *)key {
	NSSet *keyPaths = [super keyPathsForValuesAffectingValueForKey:key];
	

	return keyPaths;
}




@dynamic dateCreated;






@dynamic originData;






@dynamic primaryColorData;






@dynamic secondaryColorData;






@dynamic uniqueID;






@dynamic parts;

	
- (NSMutableOrderedSet*)partsSet {
	[self willAccessValueForKey:@"parts"];
  
	NSMutableOrderedSet *result = (NSMutableOrderedSet*)[self mutableOrderedSetValueForKey:@"parts"];
  
	[self didAccessValueForKey:@"parts"];
	return result;
}
	

@dynamic terrain;

	






@end
