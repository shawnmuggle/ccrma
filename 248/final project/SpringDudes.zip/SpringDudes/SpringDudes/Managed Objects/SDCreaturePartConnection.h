#import "_SDCreaturePartConnection.h"

@interface SDCreaturePartConnection : _SDCreaturePartConnection {}

@property (nonatomic, readonly) BOOL exploding;
@property (nonatomic) BOOL compressing;

- (void)createPhysicsRepresentation;
- (void)update;
- (void)destroyPhysicsRepresentation;

- (void)draw;

@end
