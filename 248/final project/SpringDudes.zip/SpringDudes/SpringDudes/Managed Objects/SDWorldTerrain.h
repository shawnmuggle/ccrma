#import "_SDWorldTerrain.h"

@class SDTerrainEffect;
class b2World;

@interface SDWorldTerrain : _SDWorldTerrain {}

@property (nonatomic) b2World *physicsWorld;

- (void)initializeWithWidth:(float)width andXOffset:(float)xOffset;

- (void)createPhysicsRepresentation;
- (void)updateWithTimeElapsed:(NSTimeInterval)timeElapsed;
- (void)destroyPhysicsRepresentation;

- (void)draw;

@end
