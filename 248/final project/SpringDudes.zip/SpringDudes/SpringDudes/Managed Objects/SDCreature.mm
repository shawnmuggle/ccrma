#import "SDWorld.h"
#import "SDCreature.h"
#import "SDCreaturePart.h"
#import "SDCreaturePartConnection.h"
#import "SDCreature+Convenience.h"
#import "SDCreaturePart+Convenience.h"
#import "SDGLKitHelper.h"
#import "SDSimpleEffect.h"
#import "SCKit.h"
#import "SDCreatureSound.h"
#import "SDBezierPoint.h"
#import "SDEffectsManager.h"

@interface SDCreature ()

@property (nonatomic, strong) SDCreatureSound *creatureSound;
@property (nonatomic, readwrite) BOOL alive;

- (SDCreaturePart *)addPolygonalCreaturePartWithNumSides:(int)numSides radius:(float)radius atPosition:(GLKVector2)position;
- (void)generateColors;
- (void)activateNextPartAndKeepGoing:(BOOL)keepGoing;
- (void)compressConnectionsFromCreaturePart:(SDCreaturePart *)creaturePart forSeconds:(NSTimeInterval)seconds;

@end

@implementation SDCreature
{
    SDCreaturePart *prevAddedPart;
    NSEnumerator *partsEnumerator;
    NSMutableSet *connections;
}
@synthesize creatureSound=_creatureSound, alive=_alive;

- (void)awakeFromInsert
{
    self.uniqueID = [NSString mf_stringWithUUID];
    self.dateCreated = [NSDate date];
    
    connections = [NSMutableSet set];
}

#pragma mark Properties

- (GLKVector2)centroid
{
    GLKVector2 sum = GLKVector2Make(0.0, 0.0 );
    for (SDCreaturePart *creaturePart in self.parts)
    {
        GLKVector2 pos = creaturePart.position;
        //sum = GLKVector2Add(sum, pos);  // WHY THE FUCK IS THIS GIVING ME NANs WHEN IT ADDS TWO TOTALLY FINE NUMBERS TOGETHER
        GLKVector2 newSum = GLKVector2Make(sum.x + pos.x, sum.y + pos.y);  // This is the stupidest fix/workaround EVER
        if (newSum.x != newSum.x || newSum.y != newSum.y)
        {
            NSLog(@"OLD SUM: %f %f", sum.x, sum.y);
            NSLog(@"POS: %f %f", pos.x, pos.y);
            NSLog(@"NEW SUM: %f %f", newSum.x, newSum.y);
            NSLog(@"OH NO NAN");
        }
        sum = newSum;
    }
    GLKVector2 centroid = GLKVector2DivideScalar(sum, [self.parts count]);
    
    return centroid;
}

- (BOOL)exploding
{
    if (self.alive)
    {
        for (SDCreaturePartConnection *connection in self.connections)
        {
            if (connection.exploding)
            {
                return YES;
            }
        }
    }
    return NO;
}

- (SDCreatureSound *)creatureSound
{
    if (!_creatureSound)
    {
        _creatureSound = [SDCreatureSound creatureSound];
    }
    return _creatureSound;
}

#pragma mark Editing

+ (SDCreature *)creatureInManagedObjectContext:(NSManagedObjectContext *)managedObjectContext
{
    SDCreature *creature = [self insertInManagedObjectContext:managedObjectContext];
    [creature generateColors];
    return creature;
}

- (SDCreaturePart *)addPolygonalCreaturePartWithNumSides:(int)numSides radius:(float)radius atPosition:(GLKVector2)position
{
    SDCreaturePart *creaturePart = [SDCreaturePart insertInManagedObjectContext:self.managedObjectContext];
    creaturePart.numSidesValue = numSides;
    creaturePart.radiusValue = radius;
    creaturePart.originalPosition = position;
    
    // Make this creature part unique, like a beautiful snowflake
    creaturePart.primaryColor = GLKVector3Add(GLKVector3MultiplyScalar(self.primaryColor, 0.8f), 
                                              GLKVector3MultiplyScalar([SDGLKitHelper randomGLKVector3], 0.2f));
    creaturePart.secondaryColor = GLKVector3Add(GLKVector3MultiplyScalar(self.secondaryColor, 0.8f), 
                                                GLKVector3MultiplyScalar([SDGLKitHelper randomGLKVector3], 0.2f));
    [creaturePart scaleBlueprintBy:0.8f + (arc4random() / (float)0x100000000) * 0.4f];
    
    creaturePart.creature = self;
    
    return creaturePart;
}

- (void)addPoint:(GLKVector2)position
{
    if (prevAddedPart)
    {
        GLKVector2 lastPartPosition = prevAddedPart.originalPosition;
        float distance = GLKVector2Length(GLKVector2Subtract(position, lastPartPosition));
        if (distance < 1.0f)
        {
            return; // TOO CLOSE
        }
    }
    
    int numSides = 3 + arc4random() % 6;
    SDCreaturePart *creaturePart = [self addPolygonalCreaturePartWithNumSides:numSides radius:0.5f atPosition:position];
    [creaturePart mf_broadcastCreationBy:self];
    
    if (prevAddedPart)
    {
        // Connect the parts here, and then create joints from the connections during finalization!
        SDCreaturePartConnection *connection = [SDCreaturePartConnection insertInManagedObjectContext:self.managedObjectContext];
        [prevAddedPart addConnectionsObject:connection];
        [creaturePart addConnectionsObject:connection];
        [connection mf_broadcastCreationBy:self];
        [connections addObject:connection];
    }
    
    prevAddedPart = creaturePart;
}

- (void)scaleBlueprintBy:(float)scaleFactor
{
    if (self.alive)
    {
        // Scaling only makes sense before the creature has been turned into a physics object
        return;
    }
    
    GLKVector2 centroid = self.centroid;
    for (SDCreaturePart *creaturePart in self.parts)
    {
        GLKVector2 vectorFromCentroid = GLKVector2Subtract(creaturePart.position, centroid);
        GLKVector2 scaledVectorFromCentroid = GLKVector2MultiplyScalar(vectorFromCentroid, scaleFactor);
        creaturePart.originalPosition = GLKVector2Add(centroid, scaledVectorFromCentroid);
        [creaturePart scaleBlueprintBy:scaleFactor];
    }
}

- (void)generateColors
{
    self.primaryColor = GLKVector3MultiplyScalar([SDGLKitHelper randomGLKVector3], 0.25);
    self.secondaryColor = GLKVector3MultiplyScalar([SDGLKitHelper randomGLKVector3], 0.25);
    
    int primaryColorToEnhance = arc4random() % 3;
    int primaryColorToSomewhatEnhance = arc4random() % 3;
    int secondaryColorToEnhance = arc4random() % 3;
    int secondaryColorToSomewhatEnhance = arc4random() % 3;
    
    GLKVector3 primaryColorEnhancement;
    primaryColorEnhancement.v[primaryColorToEnhance] = 0.5;
    primaryColorEnhancement.v[primaryColorToSomewhatEnhance] = 0.25;
    self.primaryColor = GLKVector3Add(self.primaryColor, primaryColorEnhancement);
    
    GLKVector3 secondaryColorEnhancement;
    secondaryColorEnhancement.v[secondaryColorToEnhance] = 0.5;
    secondaryColorEnhancement.v[secondaryColorToSomewhatEnhance] = 0.25;
    self.secondaryColor = GLKVector3Add(self.secondaryColor, secondaryColorEnhancement);
}

#pragma mark Physics

- (void)createPhysicsRepresentation
{
    if ([self.parts count] <= 2)
    {
        // You need at least 3 parts to be a real creature!
        return;
    }
    
    // TODO(mrotondo): Animate this shrinking, potentially with a nice spin too
    [self scaleBlueprintBy:0.35];
    
    // Replace the last creature part with a BIG HEAD!
    SDCreaturePart *lastPart = [self.parts lastObject];
    [lastPart turnIntoHead];
    
    for (SDCreaturePart *creaturePart in self.parts)
    {
        [creaturePart createPhysicsRepresentation];
    }
    
    for (SDCreaturePartConnection *connection in self.connections)
    {
        [connection createPhysicsRepresentation];
    }
    
    self.alive = YES;
    [[NSNotificationCenter defaultCenter] postNotificationName:SDCreatureBecameAliveNotification
                                                        object:self
                                                      userInfo:@{SDCreatureKey:self}];
    
    [self activateNextPartAndKeepGoing:YES];
}

- (void)update
{
    for (SDCreaturePart *part in self.parts)
    {
        [part update];
    }
    
    for (SDCreaturePartConnection *connection in self.connections)
    {
        [connection update];
    }
}

- (void)destroyPhysicsRepresentation
{
    [[NSNotificationCenter defaultCenter] postNotificationName:SDCreatureBecameDeadNotification
                                                        object:self
                                                      userInfo:@{SDCreatureKey:self}];
    
    self.alive = NO;
    
    for (SDCreaturePart *creaturePart in self.parts)
    {
        [creaturePart destroyPhysicsRepresentation];
    }
    
    for (SDCreaturePartConnection *connection in self.connections)
    {
        [connection destroyPhysicsRepresentation];
    }
    
    [self.creatureSound freeSynthGraph];
}

- (void)activateNextPartAndKeepGoing:(BOOL)keepGoing
{
    if (!self.alive)
    {
        return;
    }
    static float beatChoices[] = {0.125, 0.25, 0.166666, 0.5, 1.0};
    NSUInteger choice = arc4random() % 3;
    float beatLength = beatChoices[choice];
    //beatLength = 0.25; // maybe static beat length is betta, I DON KNO
    
    SDCreaturePart *creaturePart = [partsEnumerator nextObject];
    if (!creaturePart)
    {
        partsEnumerator = [self.parts objectEnumerator];
        creaturePart = [partsEnumerator nextObject];
    }
    
    GLKVector2 centroid = self.centroid;
    
    // Sonify that creature part!
    float yDifference = creaturePart.position.y - centroid.y;
    //    float distance = GLKVector2Length(GLKVector2Subtract(creaturePart.position, centroid));
    //    float frequency = fmaxf(0.0f, (300 + 100 * yDifference));
    float yDifference0to1ish = ((yDifference + 1.0f) / 2.0f);
    //    float note = floorf(yDifference0to1ish * 100.0f + 20.0f);
    //float filterFrequency = 8000 * creaturePart.scaleFactor;
    [SCBundle bundleMessages:^{
        [self.creatureSound gate].centerValueValue = 1.0f;
        [self.creatureSound setPulseFreqToMajorScaleFromFloat:yDifference0to1ish];
        //[self.creatureSound setPulseFreqToNote:note];
        //[self.creatureSound pulseFreq].centerValueValue = frequency;
        //[self.creatureSound filterFreq].centerValueValue = filterFrequency;
    }];
    
    // Physicalify that creature part!
    [self compressConnectionsFromCreaturePart:creaturePart forSeconds:beatLength];
    
    // Visualize the energy on that creature part!
    creaturePart.energy = 1.0f;
    
    if (keepGoing && self.alive)
    {
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, beatLength * NSEC_PER_SEC), 
                       dispatch_get_main_queue(), ^(void){
                           [self activateNextPartAndKeepGoing:keepGoing];
                       });
    }
}

- (NSSet *)connections
{
    if (connections)
    {
        return connections;
    }
    
    // This returns a set of sets, each containing a single connection
    NSSet *connectionsSets = [self valueForKeyPath:@"parts.connections"];
    
    // Flatten the above set to get a set of unique connections
    NSMutableSet *allConnections = [NSMutableSet setWithCapacity:[connectionsSets count]];
    for (NSSet *connectionsSet in connectionsSets)
    {
        if ([connectionsSet count])
        {
            [allConnections unionSet:connectionsSet];
        }
    }
    
    if (self.alive)
        connections = allConnections;
    
    return allConnections;
}

- (void)compressConnectionsFromCreaturePart:(SDCreaturePart *)creaturePart forSeconds:(NSTimeInterval)seconds
{
    for (SDCreaturePartConnection *connection in creaturePart.connections)
    {
        connection.compressing = YES;
    }
    
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, seconds * NSEC_PER_SEC), 
                   dispatch_get_main_queue(), ^(void){
                       [self.creatureSound gate].centerValueValue = 0.0f;
                       for (SDCreaturePartConnection *connection in creaturePart.connections)
                       {
                           connection.compressing = NO;
                       }
                   });
}

#pragma mark Graphics

- (void)drawCurvy
{
    if ([self.parts count] < 3)
        return;
    
    NSMutableSet *bezierPoints = [NSMutableSet set];
    
    SDCreaturePart *firstPart = [self.parts objectAtIndex:0];
    SDBezierPoint *firstPoint = [[SDBezierPoint alloc] initWithPosition:firstPart.position];
    SDBezierPoint *prevPoint = firstPoint;
    for (SDCreaturePart *part in self.parts)
    {
        if (part != firstPart)
        {
            SDBezierPoint *point = [[SDBezierPoint alloc] initWithPosition:part.position];
            prevPoint.nextUserPoint = point;
            
            [bezierPoints addObject:point];
            
            prevPoint = point;
        }
    }
    
    SDBezierPoint *bezierPoint = firstPoint;
    while (bezierPoint.nextUserPoint)
    {
        NSSet *interpolationPoints = [bezierPoint bezierSubdivisionToNextPointWithSpacing:0.1];
        [bezierPoints unionSet:interpolationPoints];
        bezierPoint = bezierPoint.nextUserPoint;
    }
    
    int numVertices = [bezierPoints count] * 2;
    
    GLKVector3 vertices[numVertices];
    GLKVector4 colors[numVertices];
    bezierPoint = firstPoint;
    
    int i = 0;
    while (bezierPoint.nextPoint)
    {
        GLKVector2 tangent = GLKVector2Normalize(bezierPoint.tangent);
        float width = 0.5f;
        GLKVector2 leftOffset = GLKVector2MultiplyScalar(GLKVector2Make(tangent.y, -tangent.x), width);
        GLKVector2 rightOffset = GLKVector2MultiplyScalar(GLKVector2Make(-tangent.y, tangent.x), width);
        GLKVector2 leftPoint = GLKVector2Add(bezierPoint.position, leftOffset);
        GLKVector2 rightPoint = GLKVector2Add(bezierPoint.position, rightOffset);
        
        vertices[i * 2 + 0] = GLKVector3Make(leftPoint.x, leftPoint.y, (arc4random() / (float)0x100000000));
        vertices[i * 2 + 1] = GLKVector3Make(rightPoint.x, rightPoint.y, (arc4random() / (float)0x100000000));
        
        GLKVector3 color = GLKVector3Add(self.primaryColor, GLKVector3MultiplyScalar([SDGLKitHelper randomGLKVector3], 0.2));
        colors[i * 2 + 0] = GLKVector4Make(color.r, color.g, color.b, 1.0);
        colors[i * 2 + 1] = GLKVector4Make(color.r, color.g, color.b, 1.0);
        
        i++;
        bezierPoint = bezierPoint.nextPoint;
    }
    
    SDSimpleEffect *effect = [SDEffectsManager simpleEffect];
    [effect prepareToDraw];
    
    glEnableVertexAttribArray(effect.positionVertexAttribute);
    glEnableVertexAttribArray(effect.colorVertexAttribute);
    glVertexAttribPointer(effect.positionVertexAttribute, 3, GL_FLOAT, GL_FALSE, 0, vertices);
    glVertexAttribPointer(effect.colorVertexAttribute, 4, GL_FLOAT, GL_FALSE, 0, colors);
    glDrawArrays(GL_TRIANGLE_STRIP, 0, numVertices);
    glDisableVertexAttribArray(effect.colorVertexAttribute);
}

- (void)draw
{
    [self drawCurvy];
    
    for (SDCreaturePart *part in [self.parts copy])
    {
        [part draw];
    }
    
    for (SDCreaturePartConnection *connection in [self.connections copy])
    {
        [connection draw];
    }
}

@end
