// DO NOT EDIT. This file is machine-generated and constantly overwritten.
// Make changes to SDWorldTerrain.h instead.

#import <CoreData/CoreData.h>


extern const struct SDWorldTerrainAttributes {
} SDWorldTerrainAttributes;

extern const struct SDWorldTerrainRelationships {
	__unsafe_unretained NSString *creatures;
	__unsafe_unretained NSString *world;
} SDWorldTerrainRelationships;

extern const struct SDWorldTerrainFetchedProperties {
} SDWorldTerrainFetchedProperties;

@class SDCreature;
@class SDWorld;


@interface SDWorldTerrainID : NSManagedObjectID {}
@end

@interface _SDWorldTerrain : NSManagedObject {}
+ (id)insertInManagedObjectContext:(NSManagedObjectContext*)moc_;
+ (NSString*)entityName;
+ (NSEntityDescription*)entityInManagedObjectContext:(NSManagedObjectContext*)moc_;
- (SDWorldTerrainID*)objectID;





@property (nonatomic, strong) NSSet* creatures;

- (NSMutableSet*)creaturesSet;




@property (nonatomic, strong) SDWorld* world;

//- (BOOL)validateWorld:(id*)value_ error:(NSError**)error_;





@end

@interface _SDWorldTerrain (CoreDataGeneratedAccessors)

- (void)addCreatures:(NSSet*)value_;
- (void)removeCreatures:(NSSet*)value_;
- (void)addCreaturesObject:(SDCreature*)value_;
- (void)removeCreaturesObject:(SDCreature*)value_;

@end

@interface _SDWorldTerrain (CoreDataGeneratedPrimitiveAccessors)



- (NSMutableSet*)primitiveCreatures;
- (void)setPrimitiveCreatures:(NSMutableSet*)value;



- (SDWorld*)primitiveWorld;
- (void)setPrimitiveWorld:(SDWorld*)value;


@end
