// DO NOT EDIT. This file is machine-generated and constantly overwritten.
// Make changes to SDWorldTerrain.m instead.

#import "_SDWorldTerrain.h"

const struct SDWorldTerrainAttributes SDWorldTerrainAttributes = {
};

const struct SDWorldTerrainRelationships SDWorldTerrainRelationships = {
	.creatures = @"creatures",
	.world = @"world",
};

const struct SDWorldTerrainFetchedProperties SDWorldTerrainFetchedProperties = {
};

@implementation SDWorldTerrainID
@end

@implementation _SDWorldTerrain

+ (id)insertInManagedObjectContext:(NSManagedObjectContext*)moc_ {
	NSParameterAssert(moc_);
	return [NSEntityDescription insertNewObjectForEntityForName:@"SDWorldTerrain" inManagedObjectContext:moc_];
}

+ (NSString*)entityName {
	return @"SDWorldTerrain";
}

+ (NSEntityDescription*)entityInManagedObjectContext:(NSManagedObjectContext*)moc_ {
	NSParameterAssert(moc_);
	return [NSEntityDescription entityForName:@"SDWorldTerrain" inManagedObjectContext:moc_];
}

- (SDWorldTerrainID*)objectID {
	return (SDWorldTerrainID*)[super objectID];
}

+ (NSSet *)keyPathsForValuesAffectingValueForKey:(NSString *)key {
	NSSet *keyPaths = [super keyPathsForValuesAffectingValueForKey:key];
	

	return keyPaths;
}




@dynamic creatures;

	
- (NSMutableSet*)creaturesSet {
	[self willAccessValueForKey:@"creatures"];
  
	NSMutableSet *result = (NSMutableSet*)[self mutableSetValueForKey:@"creatures"];
  
	[self didAccessValueForKey:@"creatures"];
	return result;
}
	

@dynamic world;

	






@end
