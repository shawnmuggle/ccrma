// DO NOT EDIT. This file is machine-generated and constantly overwritten.
// Make changes to SDCreaturePart.m instead.

#import "_SDCreaturePart.h"

const struct SDCreaturePartAttributes SDCreaturePartAttributes = {
	.numSides = @"numSides",
	.originalPositionData = @"originalPositionData",
	.primaryColorData = @"primaryColorData",
	.radius = @"radius",
	.secondaryColorData = @"secondaryColorData",
	.uniqueID = @"uniqueID",
};

const struct SDCreaturePartRelationships SDCreaturePartRelationships = {
	.connections = @"connections",
	.creature = @"creature",
};

const struct SDCreaturePartFetchedProperties SDCreaturePartFetchedProperties = {
};

@implementation SDCreaturePartID
@end

@implementation _SDCreaturePart

+ (id)insertInManagedObjectContext:(NSManagedObjectContext*)moc_ {
	NSParameterAssert(moc_);
	return [NSEntityDescription insertNewObjectForEntityForName:@"SDCreaturePart" inManagedObjectContext:moc_];
}

+ (NSString*)entityName {
	return @"SDCreaturePart";
}

+ (NSEntityDescription*)entityInManagedObjectContext:(NSManagedObjectContext*)moc_ {
	NSParameterAssert(moc_);
	return [NSEntityDescription entityForName:@"SDCreaturePart" inManagedObjectContext:moc_];
}

- (SDCreaturePartID*)objectID {
	return (SDCreaturePartID*)[super objectID];
}

+ (NSSet *)keyPathsForValuesAffectingValueForKey:(NSString *)key {
	NSSet *keyPaths = [super keyPathsForValuesAffectingValueForKey:key];
	
	if ([key isEqualToString:@"numSidesValue"]) {
		NSSet *affectingKey = [NSSet setWithObject:@"numSides"];
		keyPaths = [keyPaths setByAddingObjectsFromSet:affectingKey];
	}
	if ([key isEqualToString:@"radiusValue"]) {
		NSSet *affectingKey = [NSSet setWithObject:@"radius"];
		keyPaths = [keyPaths setByAddingObjectsFromSet:affectingKey];
	}

	return keyPaths;
}




@dynamic numSides;



- (int16_t)numSidesValue {
	NSNumber *result = [self numSides];
	return [result shortValue];
}

- (void)setNumSidesValue:(int16_t)value_ {
	[self setNumSides:[NSNumber numberWithShort:value_]];
}

- (int16_t)primitiveNumSidesValue {
	NSNumber *result = [self primitiveNumSides];
	return [result shortValue];
}

- (void)setPrimitiveNumSidesValue:(int16_t)value_ {
	[self setPrimitiveNumSides:[NSNumber numberWithShort:value_]];
}





@dynamic originalPositionData;






@dynamic primaryColorData;






@dynamic radius;



- (float)radiusValue {
	NSNumber *result = [self radius];
	return [result floatValue];
}

- (void)setRadiusValue:(float)value_ {
	[self setRadius:[NSNumber numberWithFloat:value_]];
}

- (float)primitiveRadiusValue {
	NSNumber *result = [self primitiveRadius];
	return [result floatValue];
}

- (void)setPrimitiveRadiusValue:(float)value_ {
	[self setPrimitiveRadius:[NSNumber numberWithFloat:value_]];
}





@dynamic secondaryColorData;






@dynamic uniqueID;






@dynamic connections;

	
- (NSMutableSet*)connectionsSet {
	[self willAccessValueForKey:@"connections"];
  
	NSMutableSet *result = (NSMutableSet*)[self mutableSetValueForKey:@"connections"];
  
	[self didAccessValueForKey:@"connections"];
	return result;
}
	

@dynamic creature;

	






@end
