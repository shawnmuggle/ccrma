#import "_SDCreature.h"

static NSString *SDCreatureBecameAliveNotification = @"SDCreatureBecameAliveNotification";
static NSString *SDCreatureBecameDeadNotification = @"SDCreatureBecameDeadNotification";
static NSString *SDCreatureKey = @"creature";

@class SDSimpleEffect;

@interface SDCreature : _SDCreature {}

@property (nonatomic, readonly) GLKVector2 centroid;
@property (nonatomic, readonly) BOOL exploding;
@property (nonatomic, readonly) BOOL alive;
@property (nonatomic, readonly) NSSet *connections;

+ (SDCreature *)creatureInManagedObjectContext:(NSManagedObjectContext *)managedObjectContext;

- (void)addPoint:(GLKVector2)point;
- (void)scaleBlueprintBy:(float)scaleFactor;  // NOTE: Only works before finalize is called

- (void)createPhysicsRepresentation;
- (void)update;
- (void)destroyPhysicsRepresentation;

- (void)draw;

@end
