// DO NOT EDIT. This file is machine-generated and constantly overwritten.
// Make changes to SDWorld.h instead.

#import <CoreData/CoreData.h>


extern const struct SDWorldAttributes {
} SDWorldAttributes;

extern const struct SDWorldRelationships {
	__unsafe_unretained NSString *terrains;
} SDWorldRelationships;

extern const struct SDWorldFetchedProperties {
} SDWorldFetchedProperties;

@class SDWorldTerrain;


@interface SDWorldID : NSManagedObjectID {}
@end

@interface _SDWorld : NSManagedObject {}
+ (id)insertInManagedObjectContext:(NSManagedObjectContext*)moc_;
+ (NSString*)entityName;
+ (NSEntityDescription*)entityInManagedObjectContext:(NSManagedObjectContext*)moc_;
- (SDWorldID*)objectID;





@property (nonatomic, strong) NSOrderedSet* terrains;

- (NSMutableOrderedSet*)terrainsSet;





@end

@interface _SDWorld (CoreDataGeneratedAccessors)

- (void)addTerrains:(NSOrderedSet*)value_;
- (void)removeTerrains:(NSOrderedSet*)value_;
- (void)addTerrainsObject:(SDWorldTerrain*)value_;
- (void)removeTerrainsObject:(SDWorldTerrain*)value_;

@end

@interface _SDWorld (CoreDataGeneratedPrimitiveAccessors)



- (NSMutableOrderedSet*)primitiveTerrains;
- (void)setPrimitiveTerrains:(NSMutableOrderedSet*)value;


@end
