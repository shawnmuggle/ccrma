#import "_SDCreaturePart.h"

class b2Body;

@interface SDCreaturePart : _SDCreaturePart {}

@property (nonatomic) float energy;
@property (nonatomic, readonly) GLKVector2 position;
@property (nonatomic, readonly) NSArray *originalVertices;
@property (nonatomic) b2Body *physicsBody;

- (void)scaleBlueprintBy:(float)scaleFactor;  // NOTE: Only works before finalizeInWorld: is called
- (void)turnIntoHead;

- (void)createPhysicsRepresentation;
- (void)update;
- (void)destroyPhysicsRepresentation;

- (void)draw;

@end
