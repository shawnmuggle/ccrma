#import "SDWorld.h"
#import "SDWorldTerrain.h"
#import "SDCreature.h"
#import "SDCreaturePart.h"
#import "SDCreaturePart+Convenience.h"
#import <Box2D/Box2D.h>
#import "SDEffectsManager.h"
#import "SDCreaturePartEffect.h"

@interface SDCreaturePart ()

@property (nonatomic, readonly) short numSidesCache;

- (void)createPhysicsBodyInWorld:(b2World *)physicsWorld;
- (void)drawEyes;

@end

@implementation SDCreaturePart
{
    b2PolygonShape *physicsShape;
    BOOL isHead;
    NSArray *originalVerticesCache;
}
@synthesize energy;
@synthesize physicsBody;
@synthesize numSidesCache;

- (void)awakeFromInsert
{
    self.uniqueID = [NSString mf_stringWithUUID];
}

#pragma mark Properties

- (GLKVector2)position
{
    if (!self.creature.alive)
    {
        return self.originalPosition;
    }
    else
    {
        b2Vec2 position = self.physicsBody->GetWorldCenter();
        return GLKVector2Make(position.x, position.y);
    }
}

- (NSArray *)originalVertices
{
    if (originalVerticesCache)
        return originalVerticesCache;
    
    float angle = 0.0f;
    NSMutableArray *vertices = [NSMutableArray arrayWithCapacity:self.numSidesCache];
    for (int i = 0; i < self.numSidesCache; i++)
    {
        angle += (2.0 * M_PI) / self.numSidesCache;
        GLKVector2 vertex = GLKVector2Make(cos(angle) * self.radiusValue, sin(angle) * self.radiusValue);
        [vertices addObject:[NSValue valueWithBytes:&vertex objCType:@encode(GLKVector2)]];
    }
    originalVerticesCache = vertices;
    return vertices;
}

- (short)numSidesCache
{
    if (numSidesCache)
        return numSidesCache;
    
    numSidesCache = self.numSidesValue;
    return numSidesCache;
}

#pragma mark Editing

- (void)scaleBlueprintBy:(float)scaleFactor
{
    if (self.creature.alive)
    {
        // Scaling only makes sense before the creature is turned into a physics object
        return;
    }

    self.radiusValue *= scaleFactor;
    originalVerticesCache = nil;
}

- (void)turnIntoHead
{
    [self scaleBlueprintBy:2.0f];
    isHead = YES;
}

#pragma mark Physics

- (void)createPhysicsBodyInWorld:(b2World *)physicsWorld
{
    b2BodyDef bodyDef;
    bodyDef.type = b2_dynamicBody;
    bodyDef.linearDamping = 1.0f;
    bodyDef.position.Set(self.originalPosition.x, self.originalPosition.y);
    
    self.physicsBody = physicsWorld->CreateBody(&bodyDef);
    physicsShape = new b2PolygonShape();
    
    NSArray *vertices = self.originalVertices;
    int numPoints = [vertices count];
    b2Vec2 *physicsVertices = (b2Vec2 *)malloc(numPoints * sizeof(b2Vec2));
    for (int i = 0; i < [vertices count]; i++)
    {
        NSValue *pointValue = [vertices objectAtIndex:i];
        GLKVector2 vertex;
        [pointValue getValue:&vertex];
        physicsVertices[i].x = vertex.x;
        physicsVertices[i].y = vertex.y;
    }
    physicsShape->Set(physicsVertices, numPoints);
    free(physicsVertices);
    
    b2FixtureDef fixtureDef;
    fixtureDef.shape = physicsShape;
    fixtureDef.density = 0.1f;
    fixtureDef.friction = 0.8f;
    fixtureDef.restitution = 0.4f;
    
    self.physicsBody->CreateFixture(&fixtureDef);
}

- (void)createPhysicsRepresentation
{
    [self createPhysicsBodyInWorld:self.creature.terrain.physicsWorld];
}

- (void)update
{
    self.energy *= 0.9f;
}

- (void)destroyPhysicsRepresentation
{
    self.creature.terrain.physicsWorld->DestroyBody(self.physicsBody);
}

#pragma mark Graphics

- (void)draw
{
    SDCreaturePartEffect *effect = [SDEffectsManager creaturePartEffect];
    
    int numVertices = 1 + self.numSidesCache + 1;  // center, vertices, first vertex again to close the tri fan
    GLfloat glVerticesArray[3 * numVertices];
    GLfloat *glVertices = glVerticesArray;
    
    GLKVector3 currentPrimaryColor = GLKVector3MultiplyScalar(GLKVector3DivideScalar(self.primaryColor, 2.0), 1.0f + self.energy);
//    GLKVector3 currentSecondaryColor = GLKVector3MultiplyScalar(GLKVector3DivideScalar(self.secondaryColor, 2.0), 1.0f + self.energy);
        
    effect.color = currentPrimaryColor;
    
    // Add the center vertex
    glVertices[0] = 0.0f;
    glVertices[1] = 0.0f;
    glVertices[2] = -1.0f;
    
    if (self.creature.alive)
    {
        // Add all vertices in order
        for (int i = 0; i < physicsShape->m_vertexCount + 1; i++)
        {
            b2Vec2 vertex = physicsShape->m_vertices[i % physicsShape->m_vertexCount];
            glVertices[(i + 1) * 3 + 0] = vertex.x * 2;
            glVertices[(i + 1) * 3 + 1] = vertex.y * 2;
            glVertices[(i + 1) * 3 + 2] = 0.0f;
        }
                
        b2Vec2 worldTranslation = physicsBody->GetWorldCenter();
        b2Vec2 localTranslation = physicsBody->GetLocalCenter();
        float rotation = physicsBody->GetAngle();
        GLKMatrix4 modelviewMatrix = GLKMatrix4Identity;
        modelviewMatrix = GLKMatrix4Translate(modelviewMatrix, worldTranslation.x, worldTranslation.y, 0.0f);
        modelviewMatrix = GLKMatrix4Rotate(modelviewMatrix, rotation, 0.0f, 0.0f, 1.0f);
        modelviewMatrix = GLKMatrix4Translate(modelviewMatrix, -localTranslation.x, -localTranslation.y, 0.0f);
        effect.transform.modelviewMatrix = modelviewMatrix;
        [effect prepareToDraw];
    }
    else
    {        
        NSArray *vertices = self.originalVertices;
        
        // Add the vertices in order
        for (int i = 0; i < [vertices count] + 1; i++)
        {
            NSValue *vertexValue = [vertices objectAtIndex:i % [vertices count]];
            GLKVector2 vertex;
            [vertexValue getValue:&vertex];
            
            glVertices[(i + 1) * 3 + 0] = vertex.x * 2;
            glVertices[(i + 1) * 3 + 1] = vertex.y * 2;
            glVertices[(i + 1) * 3 + 2] = 0.0f;
        }
        
        GLKVector2 worldTranslation = self.originalPosition;
        GLKMatrix4 modelviewMatrix = GLKMatrix4Identity;
        modelviewMatrix = GLKMatrix4Translate(modelviewMatrix, worldTranslation.x, worldTranslation.y, 0.0f);
        effect.transform.modelviewMatrix = modelviewMatrix;
        [effect prepareToDraw];
    }
    
//    glEnable(GL_BLEND);
//    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_DST_ALPHA);
    
    glEnableVertexAttribArray(effect.positionVertexAttribute);
    glVertexAttribPointer(effect.positionVertexAttribute, 3, GL_FLOAT, GL_FALSE, 0, glVertices);
    glDrawArrays(GL_TRIANGLE_FAN, 0, numVertices);
    
//    glDisable(GL_BLEND);
    
    if (isHead)
    {
        [self drawEyes];
    }
    
    // Reset the modelview matrix
    effect.transform.modelviewMatrix = GLKMatrix4Identity;
    [effect prepareToDraw];
}

- (void)drawEyes
{
    int numEyeVertices = 1 + 8 + 1;
    float eyeRadius = 0.25;

    GLfloat eyeVertices[numEyeVertices * 3];
    
    float angle = 0;
    
    eyeVertices[0] = 0.0f;
    eyeVertices[1] = 0.0f;
    eyeVertices[3] = 0.0f;

    int i;
    for (i = 0; i < numEyeVertices - 1; i++)
    {
        eyeVertices[(i + 1) * 3 + 0] = eyeRadius * cosf(angle);
        eyeVertices[(i + 1) * 3 + 1] = eyeRadius * sinf(angle);
        eyeVertices[(i + 1) * 3 + 2] = 0.0f;
        
        angle += (M_PI * 2) / (numEyeVertices - 2);
    }
    
    SDCreaturePartEffect *effect = [SDEffectsManager creaturePartEffect];

    glEnableVertexAttribArray(effect.positionVertexAttribute);
    glVertexAttribPointer(effect.positionVertexAttribute, 3, GL_FLOAT, GL_FALSE, 0, eyeVertices);
    
    GLKMatrix4 modelviewMatrix = effect.transform.modelviewMatrix;
    
    GLKMatrix4 leftEyeModelviewMatrix = GLKMatrix4Translate(modelviewMatrix, -0.35f, 0.35f, 0.0f);
    effect.transform.modelviewMatrix = leftEyeModelviewMatrix;
    effect.color = GLKVector3Make(1.0, 1.0, 1.0);
    [effect prepareToDraw];
    glDrawArrays(GL_TRIANGLE_FAN, 0, numEyeVertices);
    
    GLKMatrix4 leftPupilModelviewMatrix = GLKMatrix4Scale(leftEyeModelviewMatrix, 0.2, 0.2, 0.2);
    effect.transform.modelviewMatrix = leftPupilModelviewMatrix;
    effect.color = GLKVector3Make(0.0, 0.0, 0.0);
    [effect prepareToDraw];
    glDrawArrays(GL_TRIANGLE_FAN, 0, numEyeVertices);
    
    GLKMatrix4 rightEyeModelviewMatrix = GLKMatrix4Translate(modelviewMatrix, 0.35f, 0.35f, 0.0f);
    effect.transform.modelviewMatrix = rightEyeModelviewMatrix;
    effect.color = GLKVector3Make(1.0, 1.0, 1.0);
    [effect prepareToDraw];
    glDrawArrays(GL_TRIANGLE_FAN, 0, numEyeVertices);
    
    GLKMatrix4 rightPupilModelviewMatrix = GLKMatrix4Scale(rightEyeModelviewMatrix, 0.2, 0.2, 0.2);
    effect.transform.modelviewMatrix = rightPupilModelviewMatrix;
    effect.color = GLKVector3Make(0.0, 0.0, 0.0);
    [effect prepareToDraw];
    glDrawArrays(GL_TRIANGLE_FAN, 0, numEyeVertices);
    
    glDisableVertexAttribArray(effect.positionVertexAttribute);
}

@end
