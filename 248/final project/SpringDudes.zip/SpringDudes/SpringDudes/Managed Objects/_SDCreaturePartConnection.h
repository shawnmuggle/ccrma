// DO NOT EDIT. This file is machine-generated and constantly overwritten.
// Make changes to SDCreaturePartConnection.h instead.

#import <CoreData/CoreData.h>


extern const struct SDCreaturePartConnectionAttributes {
} SDCreaturePartConnectionAttributes;

extern const struct SDCreaturePartConnectionRelationships {
	__unsafe_unretained NSString *parts;
} SDCreaturePartConnectionRelationships;

extern const struct SDCreaturePartConnectionFetchedProperties {
} SDCreaturePartConnectionFetchedProperties;

@class SDCreaturePart;


@interface SDCreaturePartConnectionID : NSManagedObjectID {}
@end

@interface _SDCreaturePartConnection : NSManagedObject {}
+ (id)insertInManagedObjectContext:(NSManagedObjectContext*)moc_;
+ (NSString*)entityName;
+ (NSEntityDescription*)entityInManagedObjectContext:(NSManagedObjectContext*)moc_;
- (SDCreaturePartConnectionID*)objectID;





@property (nonatomic, strong) NSSet* parts;

- (NSMutableSet*)partsSet;





@end

@interface _SDCreaturePartConnection (CoreDataGeneratedAccessors)

- (void)addParts:(NSSet*)value_;
- (void)removeParts:(NSSet*)value_;
- (void)addPartsObject:(SDCreaturePart*)value_;
- (void)removePartsObject:(SDCreaturePart*)value_;

@end

@interface _SDCreaturePartConnection (CoreDataGeneratedPrimitiveAccessors)



- (NSMutableSet*)primitiveParts;
- (void)setPrimitiveParts:(NSMutableSet*)value;


@end
