#import "SDWorld.h"
#import "SDWorldTerrain.h"
#import "SDWorldState.h"
#import <Box2D/Box2D.h>
#import "SDSimpleEffect.h"
#import "SDTerrainEffect.h"
#import "SDEffectsManager.h"
#import "SDCreature.h"
#import "SDGLKitHelper.h"

@interface SDWorld ()

- (void)drawSun;
- (void)drawMoon;

@end

@implementation SDWorld
{
    SDWorldState *state;

    NSMutableArray *mutableLivingCreatures;
    
    id creatureBecameAliveObserver;
    id creatureBecameDeadObserver;
}
@synthesize initialized;

+ (SDWorld *)singletonWorldInManagedObjectContext:(NSManagedObjectContext *)managedObjectContext
{
    SDWorld *singletonWorld;
    NSError *error;
    NSFetchRequest *worldRequest = [NSFetchRequest fetchRequestWithEntityName:@"SDWorld"];
    NSArray *fetchedWorlds = [managedObjectContext executeFetchRequest:worldRequest error:&error];
    if (!fetchedWorlds)
    {
        NSLog(@"Error retrieving world: %@", error);
        return nil;
    }
    
    singletonWorld = [fetchedWorlds count] ? [fetchedWorlds objectAtIndex:0] : nil;
    if (!singletonWorld)
    {
        singletonWorld = [self insertInManagedObjectContext:managedObjectContext];

        int numTerrainsToCreate = 1;
        for (int i = 0; i < numTerrainsToCreate; i++)
        {
            SDWorldTerrain *terrain = [SDWorldTerrain insertInManagedObjectContext:singletonWorld.managedObjectContext];
            [singletonWorld.terrainsSet addObject:terrain];
        }
    }
    
    BOOL success = [managedObjectContext save:&error];
    if (!success)
    {
        NSLog(@"Error saving context after creating world: %@", error);
    }
    
    return singletonWorld;
}

- (SDWorldTerrain *)currentTerrain
{
    return [self.terrains lastObject];
}

- (void)didTurnIntoFault
{
    [[NSNotificationCenter defaultCenter] removeObserver:creatureBecameAliveObserver];
    [[NSNotificationCenter defaultCenter] removeObserver:creatureBecameDeadObserver];
}

- (void)beginTrackingCreatures
{
    mutableLivingCreatures = [NSMutableArray array];
    creatureBecameAliveObserver = [[NSNotificationCenter defaultCenter] addObserverForName:SDCreatureBecameAliveNotification object:nil queue:[NSOperationQueue mainQueue] usingBlock:^(NSNotification *note) {
        SDCreature *creature = [[note userInfo] objectForKey:SDCreatureKey];
        [mutableLivingCreatures addObject:creature];
    }];
    
    creatureBecameDeadObserver = [[NSNotificationCenter defaultCenter] addObserverForName:SDCreatureBecameDeadNotification object:nil queue:[NSOperationQueue mainQueue] usingBlock:^(NSNotification *note) {
        SDCreature *creature = [[note userInfo] objectForKey:SDCreatureKey];
        [mutableLivingCreatures removeObject:creature];
    }];
}

#pragma mark Physics

- (void)initializeWithWidth:(float)width andXOffset:(float)xOffset
{
    self.initialized = YES;
    
    state = [[SDWorldState alloc] init];
    
    for (SDWorldTerrain *terrain in self.terrains)
    {
        [terrain initializeWithWidth:width andXOffset:xOffset];
        [terrain createPhysicsRepresentation];
    }
    
    [self beginTrackingCreatures];
}

#pragma mark Physics

- (void)updateWithTimeElapsed:(NSTimeInterval)timeElapsed
{
    [state updateWithTimeElapsed:timeElapsed];

    SDTerrainEffect *terrainEffect = [SDEffectsManager terrainEffect];
    
    GLKVector3 sunPosition = GLKVector3Make(cosf(state.sunAngle), sinf(state.sunAngle), 0.0f);
    terrainEffect.sunPosition = sunPosition;
    terrainEffect.sunDiffuseColor = state.sunDiffuseColor;
    terrainEffect.sunSpecularColor = state.sunSpecularColor;
    
    GLKVector3 moonPosition = GLKVector3Make(cosf(state.moonAngle), sinf(state.moonAngle), 0.0f);
    terrainEffect.moonPosition = moonPosition;
    terrainEffect.moonDiffuseColor = state.moonDiffuseColor;
    terrainEffect.moonSpecularColor = state.moonSpecularColor;
    
    for (SDWorldTerrain *terrain in self.terrains)
    {
        [terrain updateWithTimeElapsed:timeElapsed];
    }
}

#pragma mark Graphics

- (void)draw
{
    SDTerrainEffect *terrainEffect = [SDEffectsManager terrainEffect];
    GLKMatrix4 originalModelViewMatrix = terrainEffect.transform.modelviewMatrix;
 
    GLKVector3 skyColor = state.skyColor;
    glClearColor(skyColor.x, skyColor.y, skyColor.z, 1.0f);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    
    [self drawSun];
    [self drawMoon];
    
    [self.terrains enumerateObjectsUsingBlock:^(SDWorldTerrain *terrain, NSUInteger idx, BOOL *stop) {
        GLKMatrix4 translation = GLKMatrix4Translate(originalModelViewMatrix, 0, 0, idx * 5.0f);
        terrainEffect.transform.modelviewMatrix = translation;
        [terrainEffect prepareToDraw];
        [terrain draw];
    }];
}

- (void)drawSun
{
    SDTerrainEffect *terrainEffect = [SDEffectsManager terrainEffect];
    
    int numSunTriangles = 30;
    GLKVector3 sunVertices[3 * numSunTriangles];
    GLKVector4 sunColors[3 * numSunTriangles];
    
    float sunRadius = 3.0;
    
    for (int i = 0; i < numSunTriangles; i++)
    {
        GLKVector4 color = GLKVector4Make(0.8 + 0.2 * (arc4random() / (float)0x100000000),
                                          0.8 + 0.2 * (arc4random() / (float)0x100000000),
                                          0.1 + 0.1 * (arc4random() / (float)0x100000000),
                                          1.0);
        for (int j = 0; j < 3; j++)
        {
            float vertexAngle = 2 * M_PI * (arc4random() / (float)0x100000000);
            GLKVector3 triangleVertex = GLKVector3MultiplyScalar(GLKVector3Make(cosf(vertexAngle), sinf(vertexAngle), 0.0),
                                                                 sunRadius);                                                      
            sunVertices[i * 3 + j] = GLKVector3Add(GLKVector3MultiplyScalar(terrainEffect.sunPosition, 10),
                                                   triangleVertex);
            sunColors[i * 3 + j] = color;
        }
    }
    
    SDSimpleEffect *simpleEffect = [SDEffectsManager simpleEffect];
    [simpleEffect prepareToDraw];
    
    glEnableVertexAttribArray(simpleEffect.colorVertexAttribute);
    glEnableVertexAttribArray(simpleEffect.positionVertexAttribute);
    glVertexAttribPointer(simpleEffect.colorVertexAttribute, 4, GL_FLOAT, GL_FALSE, 0, sunColors);
    glVertexAttribPointer(simpleEffect.positionVertexAttribute, 3, GL_FLOAT, GL_FALSE, 0, sunVertices);
    glDrawArrays(GL_TRIANGLES, 0, 3 * numSunTriangles);
    glDisableVertexAttribArray(simpleEffect.colorVertexAttribute);
    glDisableVertexAttribArray(simpleEffect.positionVertexAttribute);
}

- (void)drawMoon
{
    SDTerrainEffect *terrainEffect = [SDEffectsManager terrainEffect];
        
    int numMoonTriangles = 30;
    GLKVector3 moonVertices[3 * numMoonTriangles];
    GLKVector4 moonColors[3 * numMoonTriangles];
    
    float moonRadius = 2.0;
    
    for (int i = 0; i < numMoonTriangles; i++)
    {
        GLKVector4 color = GLKVector4Make(0.8 + 0.1 * (arc4random() / (float)0x100000000),
                                          0.8 + 0.1 * (arc4random() / (float)0x100000000),
                                          0.85 + 0.1 * (arc4random() / (float)0x100000000),
                                          1.0);
        for (int j = 0; j < 3; j++)
        {
            float vertexAngle = 2 * M_PI * (arc4random() / (float)0x100000000);
            GLKVector3 triangleVertex = GLKVector3MultiplyScalar(GLKVector3Make(cosf(vertexAngle), sinf(vertexAngle), 0.0),
                                                                 moonRadius);                                                      
            moonVertices[i * 3 + j] = GLKVector3Add(GLKVector3MultiplyScalar(terrainEffect.moonPosition, 9),
                                                   triangleVertex);
            moonColors[i * 3 + j] = color;
        }
    }
    
    SDSimpleEffect *simpleEffect = [SDEffectsManager simpleEffect];
    [simpleEffect prepareToDraw];
    
    glEnableVertexAttribArray(simpleEffect.colorVertexAttribute);
    glEnableVertexAttribArray(simpleEffect.positionVertexAttribute);
    glVertexAttribPointer(simpleEffect.colorVertexAttribute, 4, GL_FLOAT, GL_FALSE, 0, moonColors);
    glVertexAttribPointer(simpleEffect.positionVertexAttribute, 3, GL_FLOAT, GL_FALSE, 0, moonVertices);
    glDrawArrays(GL_TRIANGLES, 0, 3 * numMoonTriangles);
    glDisableVertexAttribArray(simpleEffect.colorVertexAttribute);
    glDisableVertexAttribArray(simpleEffect.positionVertexAttribute);
}

#pragma mark - Instance variables
- (NSArray *)livingCreatures
{
    return [mutableLivingCreatures copy];
}

@end
