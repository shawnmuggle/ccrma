#import "SDWorld.h"
#import "SDWorldTerrain.h"
#import "SDCreature.h"
#import "SDCreaturePart.h"
#import "SDCreaturePartConnection.h"
#import <Box2D/Box2D.h>
#import "SDEffectsManager.h"
#import "SDSimpleEffect.h"

float jointTranslationExplosionThreshold = 4.0f;
float maxMotorSpeed = 4.0f;

@interface SDCreaturePartConnection ()
{
    b2PrismaticJoint *joint;
}
@end

@implementation SDCreaturePartConnection
@synthesize compressing;

#pragma mark Properties

- (BOOL)exploding
{
    if (joint)
    {
        return fabs(joint->GetJointTranslation()) > jointTranslationExplosionThreshold;
    }
    else
    {
        return NO;
    }   
}

#pragma mark Physics

- (void)createPhysicsRepresentation
{
    b2Body *bodies[2];
    int i = 0;
    for (SDCreaturePart *part in self.parts)
    {
        // There will only ever be 2 and exactly 2 parts in the parts relationship.
        bodies[i++] = part.physicsBody;
    }
    
    b2Vec2 worldAxis = bodies[1]->GetWorldCenter() - bodies[0]->GetWorldCenter();
    float distance = worldAxis.Length();
    
    b2PrismaticJointDef jointDef;
    jointDef.Initialize(bodies[0], bodies[1], bodies[0]->GetWorldCenter(), worldAxis);
    jointDef.lowerTranslation = -distance / 8.0f;
    jointDef.upperTranslation = 0.1f;
    jointDef.enableLimit = false;
    jointDef.maxMotorForce = 2.0f;
    jointDef.motorSpeed = 0.0f;
    jointDef.enableMotor = true;
    
    SDCreaturePart *part = [self.parts anyObject];
    joint = (b2PrismaticJoint *)part.creature.terrain.physicsWorld->CreateJoint(&jointDef);
}

- (void)update
{
    if (joint)
    {
        if (self.compressing)
        {        
            joint->SetMotorSpeed(-2.0f);
        }
        else
        {        
            BOOL neg = NO;
            float translation = joint->GetJointTranslation();
            if (translation <= 0.0)
            {
                neg = YES;
                translation *= -1.0f;
            }
            float motorSpeed = fmin(maxMotorSpeed, powf(1.0f + translation, 5.0));
            if (!neg)
            {
                motorSpeed *= -1.0f;
            }
            joint->SetMotorSpeed(motorSpeed);
        }
    }
}

- (void)destroyPhysicsRepresentation
{
    // No-op, because joints are destroyed when the bodies that own them get destroyed
}

#pragma mark Graphics

- (void)draw
{
    int numVertices = 2;
    GLfloat vertices[3 * numVertices];
    GLfloat colors[4 * numVertices];
    
    SDCreaturePart *creatureParts[2];
    int i = 0;
    for (SDCreaturePart *part in self.parts)
    {
        // There will only ever be 2 and exactly 2 parts in the parts relationship.
        creatureParts[i++] = part;
    }
    
    GLKVector2 posA = creatureParts[0].position;
    GLKVector2 posB = creatureParts[1].position;
    vertices[0] = posA.x;
    vertices[1] = posA.y;
    vertices[2] = 0.0f;
    vertices[3] = posB.x;
    vertices[4] = posB.y;
    vertices[5] = 0.0f;
    
    float motorSpeed = 0;
    if (creatureParts[0].creature.alive && joint)
    {
        motorSpeed = fabs(joint->GetMotorSpeed()) / maxMotorSpeed;
    }
    colors[0] = motorSpeed;
    colors[1] = motorSpeed;
    colors[2] = motorSpeed;
    colors[3] = motorSpeed;
    colors[4] = motorSpeed;
    colors[5] = motorSpeed;
    colors[6] = motorSpeed;
    colors[7] = motorSpeed;
    
    SDSimpleEffect *effect = [SDEffectsManager simpleEffect];
    [effect prepareToDraw];
    
    glEnableVertexAttribArray(effect.positionVertexAttribute);
    glEnableVertexAttribArray(effect.colorVertexAttribute);
    glVertexAttribPointer(effect.positionVertexAttribute, 3, GL_FLOAT, GL_FALSE, 0, vertices);
    glVertexAttribPointer(effect.colorVertexAttribute, 4, GL_FLOAT, GL_FALSE, 0, colors);
    glDrawArrays(GL_LINES, 0, numVertices);
    glDisableVertexAttribArray(effect.colorVertexAttribute);
}

@end
