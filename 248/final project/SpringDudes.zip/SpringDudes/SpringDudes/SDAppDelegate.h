//
//  SDAppDelegate.h
//  SpringDudes
//
//  Created by Michael Rotondo on 2/19/12.
//  Copyright (c) 2012 Rototyping. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SDAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
