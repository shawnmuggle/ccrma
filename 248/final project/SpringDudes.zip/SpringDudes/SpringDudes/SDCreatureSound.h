//
//  SDCreatureSound.h
//  SpringDudes
//
//  Created by Luke Iannini on 3/4/12.
//  Copyright (c) 2012 Rototyping. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Pulsar.h"

@interface SDCreatureSound : NSObject

+ (SDCreatureSound *)creatureSound;

- (void)freeSynthGraph;

+ (SCGroup *)creatureSoundGroup;

- (RSInput *)gate;
- (RSInput *)carrierFreq;
- (RSInput *)filterFreq;

- (void)setAmp:(float)amp;
- (void)setPulseFreqToNote:(float)note;
- (void)setPulseFreqToMajorScaleFromFloat:(float)aFloat;

@end
