//
//  SDEffectsManager.h
//  SpringDudes
//
//  Created by Michael Rotondo on 3/18/12.
//  Copyright (c) 2012 Rototyping. All rights reserved.
//

#import <Foundation/Foundation.h>

static NSString *SDSimpleEffectID = @"SDSimpleEffectID";
static NSString *SDCreaturePartEffectID = @"SDCreaturePartEffectID";
static NSString *SDTerrainEffectID = @"SDTerrainEffectID";

@class SDSimpleEffect;
@class SDCreaturePartEffect;
@class SDTerrainEffect;

@interface SDEffectsManager : NSObject

+ (SDEffectsManager *)sharedEffectsManager;
+ (void)initializeSharedEffectsManager;
+ (void)destroySharedEffectsManager;

+ (void)setProjectionMatrix:(GLKMatrix4)projectionMatrix;
+ (void)setModelViewMatrix:(GLKMatrix4)modelViewMatrix;

+ (SDSimpleEffect *)simpleEffect;
+ (SDCreaturePartEffect *)creaturePartEffect;
+ (SDTerrainEffect *)terrainEffect;

@end
