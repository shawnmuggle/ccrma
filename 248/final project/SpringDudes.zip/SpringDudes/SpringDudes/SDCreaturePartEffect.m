//
//  SDSimpleEffect.m
//  SpringDudes
//
//  Created by Luke Iannini on 3/11/12.
//  Copyright (c) 2012 Rototyping. All rights reserved.
//

#import "SDCreaturePartEffect.h"
#import "sourceUtil.h"
#import "ShaderProgramLoader.h"

@implementation SDCreaturePartEffect
{
    GLuint programName;
    GLint modelViewUniformIndex;
    GLint projectionUniformIndex;
    GLint colorUniformIndex;
}
@synthesize transform;
@synthesize positionVertexAttribute;

- (id)init
{
    self = [super init];
    if (self)
    {
        //////////////////////////////////////////
		// Load and Setup shaders for rendering //
		//////////////////////////////////////////
		
		demoSource *vtxSource = NULL;
		demoSource *frgSource = NULL;
        NSString *filePathName;
		
		filePathName = [[NSBundle mainBundle] pathForResource:@"creaturepart" ofType:@"vsh"];
		vtxSource = srcLoadSource([filePathName cStringUsingEncoding:NSASCIIStringEncoding]);
		
		filePathName = [[NSBundle mainBundle] pathForResource:@"creaturepart" ofType:@"fsh"];
		frgSource = srcLoadSource([filePathName cStringUsingEncoding:NSASCIIStringEncoding]);
		
		// Build Program
		programName = [ShaderProgramLoader buildProgramWithVertexSource:vtxSource
                                                         withFragmentSource:frgSource
                                                                  withColor:NO
                                                                 withNormal:NO
                                                               withTexCoord:NO];
		
		srcDestroySource(vtxSource);
		srcDestroySource(frgSource);
		
		modelViewUniformIndex = glGetUniformLocation(programName, "modelViewMatrix");
		if(modelViewUniformIndex < 0)
		{
			NSLog(@"No modelViewMatrix in creature part shader");
		}
        
        projectionUniformIndex = glGetUniformLocation(programName, "projectionMatrix");
		if(projectionUniformIndex < 0)
		{
			NSLog(@"No projectionMatrix in creature part shader");
		}
        
        colorUniformIndex = glGetUniformLocation(programName, "color");
		if(colorUniformIndex < 0)
		{
			NSLog(@"No color in creature part shader");
		}
        
        transform = [[GLKEffectPropertyTransform alloc] init];
        
        // These are determined in the ShaderProgramLoader buildProgram method
        self.positionVertexAttribute = POS_ATTRIB_IDX;
    }
    return self;
}

- (void) dealloc
{
	[ShaderProgramLoader destroyProgram:programName];
}

- (void)prepareToDraw
{
    // Use the program for rendering the world
	glUseProgram(programName);

    // Have our shader use the modelview & projection matrices that we calculated above
    glUniformMatrix4fv(projectionUniformIndex, 1, GL_FALSE, transform.projectionMatrix.m);
	glUniformMatrix4fv(modelViewUniformIndex, 1, GL_FALSE, transform.modelviewMatrix.m);

    glUniform3fv(colorUniformIndex, 1, self.color.v);
}

@end
