//
//  ROPathPoint.h
//  PathStyleTest
//
//  Created by Michael Rotondo on 1/6/12.
//  Copyright (c) 2012 Rototyping. All rights reserved.
//


// ROPathPoint is a doubly-linked list object which represents an XY position.
// It can calculate information about the distance and angle to its neighbors.
// It can also create points between itself and its next neighbor using bezier
// interpolation, with a user-specifiable minimum spacing between points.

#import <Foundation/Foundation.h>

@interface SDBezierPoint : NSObject 

@property (nonatomic, weak) SDBezierPoint *nextPoint;
@property (nonatomic, weak) SDBezierPoint *prevPoint;

// For points originating from user input instead of interpolation, we hold onto the user-provided prev & next points so that we can interpolate between these points properly, instead of using the interpolated points to calculate tangents etc
@property (nonatomic, weak) SDBezierPoint *nextUserPoint;
@property (nonatomic, weak) SDBezierPoint *prevUserPoint;

// Dynamically-calculated properties
@property (nonatomic) GLKVector2 position;
@property (nonatomic) float distanceAlongPath;
@property (nonatomic, readonly) float distanceToPrevPoint;
@property (nonatomic, readonly) float distanceToNextPoint;
@property (nonatomic, readonly) float slope;
@property (nonatomic, readonly) GLKVector2 tangent;

- (id)initWithPosition:(GLKVector2)position;
- (float)distanceToPoint:(SDBezierPoint *)otherPoint;
- (NSSet *)bezierSubdivisionToNextPointWithSpacing:(float)spacing;

@end
