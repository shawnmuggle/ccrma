//
//  SDWorldState.h
//  SpringDudes
//
//  Created by Michael Rotondo on 3/19/12.
//  Copyright (c) 2012 Rototyping. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SDWorldState : NSObject

- (void)updateWithTimeElapsed:(NSTimeInterval)timeElapsed;

@property (nonatomic, readonly) GLKVector3 skyColor;

@property (nonatomic, readonly) float sunAngle;
@property (nonatomic, readonly) GLKVector3 sunDiffuseColor;
@property (nonatomic, readonly) GLKVector3 sunSpecularColor;

@property (nonatomic, readonly) float moonAngle;
@property (nonatomic, readonly) GLKVector3 moonDiffuseColor;
@property (nonatomic, readonly) GLKVector3 moonSpecularColor;


@end
