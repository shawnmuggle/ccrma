//
//  SDSecretGesture.m
//  SpringDudes
//
//  Created by Luke Iannini on 3/18/12.
//  Copyright (c) 2012 Rototyping. All rights reserved.
//

#import "SDSecretGesture.h"



@implementation SDSecretGesture
{
    NSDate *tap1Date;
    NSDate *tap2Date;
    NSDate *tap3Date;
    NSDate *tap4Date;
    
    __weak UIView *view;
    SDSecretGestureBlock block;
}

+ (SDSecretGesture *)secretGestureAddedToView:(UIView *)aView withEffect:(SDSecretGestureBlock)aBlock
{
    return [[self alloc] initWithView:aView withEffect:aBlock];
}

- (id)initWithView:(UIView *)aView withEffect:(SDSecretGestureBlock)aBlock
{
    self = [super init];
    if (self) {
        view = aView;
        block = [aBlock copy];
        [self setup];
    }
    return self;
}

- (void)setup
{
    UITapGestureRecognizer *tap1Recognizer = [[UITapGestureRecognizer alloc] initWithTarget:self
                                                                                     action:@selector(handleTap1:)];
    
    UITapGestureRecognizer *tap2Recognizer = [[UITapGestureRecognizer alloc] initWithTarget:self
                                                                                     action:@selector(handleTap2:)];
    
    UITapGestureRecognizer *tap3Recognizer = [[UITapGestureRecognizer alloc] initWithTarget:self
                                                                                     action:@selector(handleTap3:)];
    
    UITapGestureRecognizer *tap4Recognizer = [[UITapGestureRecognizer alloc] initWithTarget:self
                                                                                     action:@selector(handleTap4:)];
    
    tap1Recognizer.cancelsTouchesInView = NO;
    tap2Recognizer.cancelsTouchesInView = NO;
    tap3Recognizer.cancelsTouchesInView = NO;
    tap4Recognizer.cancelsTouchesInView = NO;
    
    [view addGestureRecognizer:tap1Recognizer];
    [view addGestureRecognizer:tap2Recognizer];
    [view addGestureRecognizer:tap3Recognizer];
    [view addGestureRecognizer:tap4Recognizer];
}
#define kTapWidth 44
#define kMaxTimeBetweenTaps 2
- (void)handleTap1:(UITapGestureRecognizer *)recognizer
{
    CGRect topLeftRect = CGRectMake(0, 0,
                                    kTapWidth, kTapWidth);
    if (CGRectContainsPoint(topLeftRect, [recognizer locationInView:view]))
    {
        tap1Date = [NSDate date];
    }
}

- (void)handleTap2:(UITapGestureRecognizer *)recognizer
{
    CGRect topLeftRect = CGRectMake(view.bounds.size.width - kTapWidth, 0,
                                    kTapWidth, kTapWidth);
    if (CGRectContainsPoint(topLeftRect, [recognizer locationInView:view]) &&
        abs([tap1Date timeIntervalSinceNow]) < kMaxTimeBetweenTaps)
    {
        tap2Date = [NSDate date];
    }
}

- (void)handleTap3:(UITapGestureRecognizer *)recognizer
{
    CGRect topLeftRect = CGRectMake(view.bounds.size.width - kTapWidth, view.bounds.size.height - kTapWidth,
                                    kTapWidth, kTapWidth);
    if (CGRectContainsPoint(topLeftRect, [recognizer locationInView:view]) &&
        abs([tap2Date timeIntervalSinceNow]) < kMaxTimeBetweenTaps)
    {
        tap3Date = [NSDate date];
    }
}

- (void)handleTap4:(UITapGestureRecognizer *)recognizer
{
    CGRect topLeftRect = CGRectMake(0, view.bounds.size.height - kTapWidth,
                                    kTapWidth, kTapWidth);
    if (CGRectContainsPoint(topLeftRect, [recognizer locationInView:view]) &&
        abs([tap3Date timeIntervalSinceNow]) < kMaxTimeBetweenTaps)
    {
        block();
    }
}

@end
