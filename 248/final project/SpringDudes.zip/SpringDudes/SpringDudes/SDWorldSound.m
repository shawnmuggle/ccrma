//
//  SDWorldSound.m
//  SpringDudes
//
//  Created by Luke Iannini on 3/11/12.
//  Copyright (c) 2012 Rototyping. All rights reserved.
//

#import "SDWorldSound.h"
#import "SCKit.h"
#import "Pulsar.h"
#import "SDCreatureSound.h"

@implementation SDWorldSound
{
    RSGraph *effectsGraph;
}

+ (SCGroup *)worldEffectsGroup
{
    static SCGroup *worldEffectsGroup;
    if (!worldEffectsGroup) 
    {
        worldEffectsGroup = [SCGroup groupSendLater:YES];
        worldEffectsGroup.target = [SDCreatureSound creatureSoundGroup];
        worldEffectsGroup.addAction = SCAddAfterAction;
        [worldEffectsGroup send];
    }
    return worldEffectsGroup;
}

+ (SDWorldSound *)defaultWorldSound
{
    static SDWorldSound *worldSound;
    if (!worldSound) 
    {
        worldSound = [[self alloc] init];
    }
    return worldSound;
}

- (id)init
{
    self = [super init];
    if (self) {
        effectsGraph = [[Pulsar sharedPulsar] graphNamed:@"Effects" creation:^(RSGraph *newGraph) {
            
            RSNode *inputNode = [newGraph addNodeWithID:@"input" fromSynthDefNamed:@"Out"];
            
            // Connect input to filter
            RSNode *filterNode = [newGraph addNodeWithID:@"filter" fromSynthDefNamed:@"RLPF-AR"];
            [filterNode controlNamed:@"freq"].centerValueValue = 3000;
            [filterNode controlNamed:@"freq"].modDepthValue = 2000;
            [filterNode controlNamed:@"rq"].centerValueValue = 0.1;
            
            [RSWire wireFrom:inputNode to:[filterNode controlNamed:@"a_in"] atAmp:1.0f];
            
            // Connect filter to reverb
            RSNode *reverbNode = [newGraph addNodeWithID:@"reverb" fromSynthDefNamed:@"FreeVerb-AR"];
            [reverbNode controlNamed:@"mix"].centerValueValue = 0.5;
            [reverbNode controlNamed:@"room"].centerValueValue = 0.5;
            
            [RSWire wireFrom:filterNode to:[reverbNode controlNamed:@"a_in"] atAmp:1.0f];
            
            // Connect modulator to reverb room size and filter freq
            RSNode *sineWave1 = [newGraph addNodeWithID:@"mod1" fromSynthDefNamed:@"SinOsc-KR"];
            [sineWave1 controlNamed:@"freq"].centerValueValue = 0.1;
            
            [RSWire wireFrom:sineWave1 to:[reverbNode controlNamed:@"room"] atAmp:0.5];
            
            RSNode *sineWave2 = [newGraph addNodeWithID:@"mod" fromSynthDefNamed:@"SinOsc-KR"];
            [sineWave2 controlNamed:@"freq"].centerValueValue = 1;
            
            [RSWire wireFrom:sineWave2 to:[filterNode controlNamed:@"freq"] atAmp:-1.0];
            
            // Connect reverb to output
            [RSWire wireFrom:reverbNode to:[newGraph.outNode controlNamed:@"a_in"] atAmp:1.0f];
        }];
        
        [SCBundle bundleMessages:^{
            effectsGraph.superGroup = [[self class] worldEffectsGroup];
            [effectsGraph spawn];
            [effectsGraph connectOutToBus:[SCBus mainOutputBus]];
        }];
    }
    return self;
}

- (RSInput *)input
{
    return [[effectsGraph nodeWithID:@"input"] controlNamed:@"a_in"];
}

@end
