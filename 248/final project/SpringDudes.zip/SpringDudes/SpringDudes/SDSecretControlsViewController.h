//
//  SDSecretControlsViewController.h
//  SpringDudes
//
//  Created by Luke Iannini on 3/18/12.
//  Copyright (c) 2012 Rototyping. All rights reserved.
//

#import <UIKit/UIKit.h>

@class SDSecretControlsViewController;
@protocol SDSecretControlsViewControllerDelegate <NSObject>

- (void)secretControlsViewControllerDidFinish:(SDSecretControlsViewController *)aSecretControlsViewController;

@end

@interface SDSecretControlsViewController : UIViewController
@property (nonatomic, weak) id <SDSecretControlsViewControllerDelegate> delegate;
@end
