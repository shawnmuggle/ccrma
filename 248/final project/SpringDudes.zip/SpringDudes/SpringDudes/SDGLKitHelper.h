//
//  SDGLKitHelper.h
//  SpringDudes
//
//  Created by Michael Rotondo on 3/8/12.
//  Copyright (c) 2012 Rototyping. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "glUtil.h"

#define GetGLError()									\
{														\
GLenum err = glGetError();							\
while (err != GL_NO_ERROR) {						\
NSLog(@"GLError %s set in File:%s Line:%d\n",	\
GetGLErrorString(err),					\
__FILE__,								\
__LINE__);								\
err = glGetError();								\
}													\
}

@interface SDGLKitHelper : NSObject

+ (GLKVector2)randomGLKVector2;
+ (GLKVector3)randomGLKVector3;
+ (GLKVector4)randomGLKVector4;

@end
