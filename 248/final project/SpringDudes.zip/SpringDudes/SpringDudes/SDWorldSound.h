//
//  SDWorldSound.h
//  SpringDudes
//
//  Created by Luke Iannini on 3/11/12.
//  Copyright (c) 2012 Rototyping. All rights reserved.
//

#import <Foundation/Foundation.h>

@class RSInput;
@interface SDWorldSound : NSObject

+ (SDWorldSound *)defaultWorldSound;

- (RSInput *)input;

@end
