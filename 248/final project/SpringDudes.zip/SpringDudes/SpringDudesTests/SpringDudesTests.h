//
//  SpringDudesTests.h
//  SpringDudesTests
//
//  Created by Michael Rotondo on 2/19/12.
//  Copyright (c) 2012 Rototyping. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface SpringDudesTests : SenTestCase

@end
