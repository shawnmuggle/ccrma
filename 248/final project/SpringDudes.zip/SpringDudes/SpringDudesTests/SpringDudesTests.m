//
//  SpringDudesTests.m
//  SpringDudesTests
//
//  Created by Michael Rotondo on 2/19/12.
//  Copyright (c) 2012 Rototyping. All rights reserved.
//

#import "SpringDudesTests.h"

@implementation SpringDudesTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    STFail(@"Unit tests are not implemented yet in SpringDudesTests");
}

@end
