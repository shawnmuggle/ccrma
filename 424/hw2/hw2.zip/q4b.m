% The values I used to get an impulse response that sounded like
% memchu_bpeq.wav were:

% T60 High: 3.8s
% T60 Low: 0.41s
% Transition Freq: 9959 Hz

% I also used an EQ on the reverb (not on the original impulse). Its
% settings were:

% GainLow: -4.79dB
% GainMid: -1.62dB
% GainHi: -2.57dB
% FreqLow: 1.2kHz (?!)
% FreqHi: 1.1kHz (?!?!?!)
% (Clearly this is a little screwy, but it's sounding good and I'm tired)